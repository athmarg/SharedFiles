#include <stdio.h>
#include <stdlib.h>

#define Length 1048576 /* This is the vectors size */
#define MAXVAL 10000   /* This is the maximum data value */
#define TPB 256        /* The number of threads per block */

/* The source code of the kernel for the vector addition */
__global__ void addVector (double *a, double *b, double *c) {
   int threadId = blockDim.x * blockIdx.x + threadIdx.x;
   if (threadId < Length)
   c[threadId] = a[threadId] + b[threadId]; }
   
/* The main program running at host machine */
int main() {
   int blocksInGrid = ceil(float(Length)/TPB);
   double *cpuA, *cpuB, *cpuC; /* Vectors on host */
   double *gpuA, *gpuB, *gpuC; /* Vectors on device */
   // Allocate memory for vectors A, B, and C on host
   cpuA = (double*)malloc(Length*sizeof(double));
   cpuB = (double*)malloc(Length*sizeof(double));
   cpuC = (double*)malloc(Length*sizeof(double));
   // Allocate memory for vectors gpuA, gpuB and gpuC
   cudaMalloc(&gpuA, Length*sizeof(double));
   cudaMalloc(&gpuB, Length*sizeof(double));
   cudaMalloc(&gpuC, Length*sizeof(double));
   /* Init vectors cpuA and cpuB in random values */
   /* in the interval [0->MAXVAL-1] */
   for (int i=0;i<Length;i++) {
   cpuA[i] = MAXVAL*((double)rand()/RAND_MAX);
   cpuB[i] = MAXVAL*((double)rand()/RAND_MAX); }
   /* Copy data from host vectors cpuA and cpuB */
   /* to device vectors gpuA and gpuB */
   cudaMemcpy(gpuA, cpuA, Length*sizeof(double),cudaMemcpyHostToDevice);
   cudaMemcpy(gpuB, cpuB, Length*sizeof(double),cudaMemcpyHostToDevice);
   // Launch kernel in GPU to perform vector addition
   addVector <<< blocksInGrid, TPB >>>(gpuA, gpuB, gpuC);
   // Copy data from device vector gpuC to host vector cpuC
   cudaMemcpy(cpuC, gpuC, Length*sizeof(double),cudaMemcpyDeviceToHost);
   // Free memory in host device
   free(cpuA); free(cpuB); free(cpuC);
   // Free memory in GPU device
   cudaFree(gpuA); cudaFree(gpuB); cudaFree(gpuC);
   return 0; }
   
   
