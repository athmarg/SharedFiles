#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <cuda_runtime.h>

// 0 to dispable print, 1 to enable print
int print = 0;

typedef struct mulStruct {
   dim3 blocks;   /* blocks per grid   */
   dim3 threads;  /* threads per block */
   char mode[15]; /* parallelization mode (single, tile, block, blockTile, blockThread) */
   int  size;     /* the size of square matrices */
   int  tiledim; } mulStruct;

// Kernel for the "Single" mode of operation: One block with NxN threads
// Each thread computes one single value

__global__ void matMultSingle (double * matA, double * matB, double * matC, int N) {
    int row = threadIdx.y, column = threadIdx.x;
    double temp=0;
    if (row<N && column<N) {
        for (int i=0;i<N;i++) {
            temp += matA[row*N+i]*matB[i*N+column]; }
        matC[row*N+column]=temp; }}

// Kernel fore the "Tile" mode of operation: One block with 32x32 threads 
// Each thread computes the values of cells forming a tile

__global__ void matMultWithTile (double * matA, double * matB, 
                double * matC, int N) {
    int tiledim=N/32;
    int startRow = threadIdx.y*tiledim;
    int startColumn = threadIdx.x*tiledim;
    int endRow = startRow + tiledim;
    int endColumn = startColumn + tiledim;
    double a,b,temp;
    for (int i=startRow;i<endRow;i++) {
         for (int j=startColumn;j<endColumn;j++) {
              temp = 0.0;
              for (int k=0;k<N;++k) {
                   a = matA[i*N+k];
                   b = matB[k*N+j];
                   temp += a*b; }
              matC[i*N+j] =  temp; }}}
    
// Kernel for the "Block" mode of operation: Many blocks with MxM threads where M>N
// Each thread computes one single value

__global__ void matMultWithBlock (double * matA, double * matB, 
                double * matC, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int column = blockIdx.x * blockDim.x + threadIdx.x;    
    double temp=0;
    if (row<N && column<N) {
        for (int i=0;i<N;i++) {
            temp += matA[row*N+i]*matB[i*N+column]; }
        matC[row*N+column]=temp; }}
    
// Kernel for the "Block-Tile" mode of operation: Many blocks with MxM threads where M>N
// Each thread computes the values of cells forming a tile

__global__ void matMultWithBlockTile (double * matA, double * matB, 
                double * matC, int N, int tiledim) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int column = blockIdx.x * blockDim.x + threadIdx.x;    
    double a,b,temp; 
    int startRow = row*tiledim;
    int startColumn = column*tiledim;
    int endRow = startRow + tiledim;
    int endColumn = startColumn + tiledim;
    for (int i=startRow;i<endRow;i++) {
         for (int j=startColumn;j<endColumn;j++) {
              temp = 0.0;
              for (int k=0;k<N;++k) {
                   a = matA[i*N+k];
                   b = matB[k*N+j];
                   temp += a*b; }
              matC[i*N+j] =  temp; }}}   
              
// Kernel for the "Block-Shared" mode of operation: Many blocks with MxM threads where M>N
// Each thread computes one single value but with a tile loaded in shared memory

__global__ void matMultWithBlockShared (double * matA, double * matB, 
                double * matC, int N, int tiledim) {
    int row = blockIdx.y, column = blockIdx.x, tiles = N/tiledim;   
    int tileRow = threadIdx.y, tileColumn = threadIdx.x;   
    double sum = 0.0; 
    extern __shared__ double shGPUMem[];
    double *sharedA = shGPUMem;
    double *sharedB = (double *)&sharedA[tiledim*tiledim];
    double *cellA, *cellB, *cellC = &matC[N*tiledim*row+tiledim*column]; 
    for (int i=0;i<tiles;++i) {
         cellA = &matA[N*tiledim*row+tiledim*i];
         cellB = &matB[N*tiledim*i+tiledim*column]; 
         sharedA[tileRow*tiledim+tileColumn] = cellA[tileRow*N+tileColumn]; // here
         sharedB[tileRow*tiledim+tileColumn] = cellB[tileRow*N+tileColumn];         
         __syncthreads();
         for (int j=0;j<tiledim;j++)
              sum += sharedA[tileRow*tiledim+j]*sharedB[j*tiledim+tileColumn];
         __syncthreads(); }
    cellC[tileRow*N+tileColumn] = sum; }                  
              
/* The launcher (or wrapper) of the kernel functions. It gets as input the configuration */
/* strcture with the user defined options and launch the appropriate kernel              */

void multiply (double * matA, double * matB, double * matC, mulStruct * config){
    double *gpuA, *gpuB, *gpuC;  /* Matrices on device */
    char mode[15]; 
    int N = config->size; 
    strcpy (mode,config->mode);
    int tile = config->tiledim;
    dim3 blocks,threads;
    int L = 2*tile*tile*sizeof(double);
    blocks.x = config->blocks.x;
    blocks.y = config->blocks.y;    
    threads.x = config->threads.x;
    threads.y = config->threads.y;    
    // Allocate memory for devuce matrices (gpuA, gpuB, gpuC) 
    cudaMalloc(&gpuA, N*N*sizeof(double));
    cudaMalloc(&gpuB, N*N*sizeof(double));
    cudaMalloc(&gpuC, N*N*sizeof(double));
    /* Copy data from host vectors matA and matB  */
    /* to device vectors gpuA and gpuB            */
    cudaMemcpy(gpuA, matA, N*N*sizeof(double), cudaMemcpyHostToDevice);
    cudaMemcpy(gpuB, matB, N*N*sizeof(double), cudaMemcpyHostToDevice);    
    /* Call kernel function to perform the parallel */
    /* matrix multiplication */
    if (!strcmp(mode,"single")) matMultSingle <<<blocks,threads>>> (gpuA, gpuB, gpuC, N); 
    else if (!strcmp(mode,"tile")) matMultWithTile <<<blocks,threads>>> (gpuA, gpuB, gpuC, N); 
    else if (!strcmp(mode,"block")) matMultWithBlock <<<blocks,threads>>> (gpuA, gpuB, gpuC, N);   
    else if (!strcmp(mode,"blockTile")) matMultWithBlockTile <<<blocks,threads>>> (gpuA, gpuB, gpuC, N, tile); 
    else if (!strcmp(mode,"blockShared")) matMultWithBlockShared <<<blocks,threads,L>>> (gpuA, gpuB, gpuC, N, tile); 
    else { printf ("Please use a valid mode\n"); exit (-1); }
    cudaError_t err = cudaGetLastError();
    if (err!=cudaSuccess) {
        printf("CUDA Error: %s\n", cudaGetErrorString(err));       
        exit (-1);}
    /* Synchronize threads in the grid */    
    cudaDeviceSynchronize(); 
    // Copy data from device (gpuC) to host (cpuC)
    cudaMemcpy(matC, gpuC, N*N*sizeof(double), cudaMemcpyDeviceToHost);
    // Free memory in GPU device
    cudaFree(gpuA); cudaFree(gpuB); cudaFree(gpuC); }

/* This function reads the user preferences from the command line and initializes accordingly the members */
/* of a mulStruct data structure and returns this structure to the main function                          */

mulStruct appInit (int argc, char ** argv, int * retCode) {
    mulStruct retVal = {0,0,"Undefined,0,0"}; 
    char mode[15]; int size = 0, tiledim = 0; *retCode = 0;
    if (argc!=3) { *retCode = -1; return retVal;}
    else { 
          size = atoi(argv[1]); 
          if (size<0) { 
              retVal.size = 32; 
              printf ("appInit: Invalid size is set to 32\n"); }
          else retVal.size = size;
          strcpy (mode, argv[2]); 
          if ((strcmp(mode,"single"))&&(strcmp(mode,"tile"))&&
              (strcmp(mode,"block"))&&(strcmp(mode,"blockTile")&&
              (strcmp(mode,"blockShared")))) {
                      printf ("appInit: Invalid mode is set to single\n"); 
                      strcpy(retVal.mode,"single");
                      retVal.threads.x=retVal.threads.y=retVal.size; 
                      retVal.blocks.x=retVal.blocks.y=1; }
          if ((!strcmp(mode,"blockTile"))||(!strcmp(mode,"blockShared"))) {
               printf ("Give tile dimension [1,2,4,8,16,32]: ");
               scanf ("%d",&tiledim);
               if ((tiledim!=1)&&(tiledim!=2)&&(tiledim!=4)&&
                   (tiledim!=8)&&(tiledim!=16)&&(tiledim!=32)) {
                    retVal.tiledim = 1;  
                    printf ("appInit: Invalid tile dimension (%d) is set to 1\n", tiledim); }
               else retVal.tiledim = tiledim; }
          if (size>32&&(!strcmp(mode,"single"))) { 
              *retCode = -2; 
              return retVal;}
          if (!strcmp(mode,"single")) {
              strcpy(retVal.mode,"single");
              retVal.threads.x=retVal.threads.y=retVal.size; 
              retVal.blocks.x=retVal.blocks.y=1; }
          if (!strcmp(mode,"tile")) {        
              strcpy(retVal.mode,"tile");     
              retVal.threads.x=retVal.threads.y=32; 
              retVal.blocks.x=retVal.blocks.y=1; }  
          if (!strcmp(mode,"block")) {               
              strcpy(retVal.mode,"block");  
              if (retVal.size<32) retVal.size = 32;
                  printf ("appInit: Matrix dimension is set to 32\n");
                  retVal.threads.x=retVal.threads.y=32; 
                  retVal.blocks.x=retVal.blocks.y=retVal.size/32; }   
          if (!strcmp(mode,"blockTile")) {                       
              strcpy(retVal.mode,"blockTile"); 
              if (retVal.size<32) {
                  retVal.size = 32;
                  printf ("appInit: Matrix dimension is set to 32\n"); }       
              retVal.threads.x=retVal.threads.y=32/retVal.tiledim; 
              retVal.blocks.x=retVal.blocks.y=retVal.size/32; }  
          if (!strcmp(mode,"blockShared")) {                               
              strcpy(retVal.mode,"blockShared");
              if (retVal.size<32) {
                  retVal.size = 32;
                  printf ("appInit: Matrix dimension is set to 32\n");  }
              retVal.threads.x=retVal.threads.y=retVal.tiledim; 
              retVal.blocks.x=retVal.blocks.y=retVal.size/retVal.tiledim; } 
    return (retVal); }}
    
/* This function prints the data values stored in a mulStruct structure */

void PrintMulStruct (mulStruct mulStr) {
   printf ("\nExecution Configuration\n"); 
   printf ("-----------------------\n\n");
   printf ("Matrix size: %d\n", mulStr.size);
   printf ("Operation mode: %s\n",mulStr.mode);   
   printf ("Threads: %dx%d, Blocks: %dx%d\n", 
            mulStr.threads.x,mulStr.threads.y, 
            mulStr.blocks.x,mulStr.blocks.y);  
   if ((!strcmp(mulStr.mode,"blockTile"))||
       (!strcmp(mulStr.mode,"blockShared")))            
        printf ("Tile dimension: %d\n\n", mulStr.tiledim);
   else printf ("WARNING: Tile dimension is not used\n\n"); }    

/* The main function that performs the matrix multiplication in CUDA */

int main(int argc, char ** argv) {
    float elapsedTime = 0.0; 
    double *cpuA, *cpuB, *cpuC;  /* Matrices on host   */    
    int errCode; mulStruct config = appInit (argc, argv, &errCode);
    if (errCode==-1) { 
        printf ("Usage: matrixMulOneBlock size mode\n"); exit (-1); }
    if (errCode==-2) {
        printf("Maxdim in this CUDA implementation is 32\n");
        printf("since 32x32=1024 is the max TPB value \n");
        printf("Use a smaller value for size of matrices\n");
        exit (-2); }          
    if (!errCode) PrintMulStruct(config);
    // Allocate memory for matrices A, B, and C on host    
    cpuA = (double*)malloc(config.size*config.size*sizeof(double));
    cpuB = (double*)malloc(config.size*config.size*sizeof(double));
    cpuC = (double*)malloc(config.size*config.size*sizeof(double));    
    for (int i=0;i<config.size;i++){
         for (int j=0;j<config.size;j++){
              cpuA[i*config.size+j] = (double)rand()/RAND_MAX;
              cpuB[i*config.size+j] = (double)rand()/RAND_MAX;
              cpuC[i*config.size+j] = 0.0; }}
    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);
    cudaEventRecord(start,0);              
    // Call multiply to take care of GPU stuff
    multiply (cpuA, cpuB, cpuC, &config);
    cudaEventRecord(stop,0);   
    cudaEventSynchronize(stop); 
    cudaEventElapsedTime(&elapsedTime,start,stop);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);    
    printf("GPU Time elapsed: %f milliseconds \n\n", elapsedTime);    
    // On return, cpuC containts the data of matrix product
    // Print data for debugging purposes 
    if (print==1) {
        for (int i=0;i<config.size;i++){
             for (int j=0;j<config.size;j++)
                  printf ("%.3f ",cpuC[i*config.size+j]);
             printf("\n"); } }
    // Free memory in host device
    free(cpuA); free(cpuB); free(cpuC);
    return 0; }
    
    
    
    
    

