#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 8 

int main (int argc, char ** argv) {
    int i, j, rank, size;
    double aMatrix[DIM][DIM];
    double bMatrix[DIM][DIM];
    int blockArray[DIM];
    int dispArray[DIM];
    MPI_Datatype matType;
    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number.\n");
        MPI_Finalize();
        return (-1); }
    for (i=0;i<DIM;i++) {
         for (j=0;j<DIM;j++) {
              aMatrix[i][j]=(double)rand()/RAND_MAX;
              bMatrix[i][j]=0.0; }}
    for (i=0;i<DIM;i++) {
         blockArray[i] = DIM-i;
         dispArray[i] = i*DIM+i; }
    MPI_Type_indexed (DIM,blockArray,dispArray,
                      MPI_DOUBLE,&matType);
    MPI_Type_commit (&matType);
    if (rank==0) {
        printf ("MATRIX A ELEMENTS\n");
        for (i=0;i<DIM;i++) {
             printf ("\n");
             for (j=0;j<DIM;j++) {
                  printf ("%.3f ", aMatrix[i][j]); }}
        MPI_Send (&aMatrix[0][0],1,matType,1,0,
                  MPI_COMM_WORLD); }
    else {
        MPI_Recv(&bMatrix[0][0], 1, matType, 0, 0,
                 MPI_COMM_WORLD, &status);
        printf ("\nMATRIX B ELEMENTS\n");
        for (i=0;i<DIM;i++) {
             printf ("\n");
             for (j=0;j<DIM;j++) {
                  printf ("%.3f ", bMatrix[i][j]); }}}
    printf ("\n");
    MPI_Type_free (&matType);
    MPI_Finalize ();
    return (0); }
