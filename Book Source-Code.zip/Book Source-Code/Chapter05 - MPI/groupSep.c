#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 4

int main (int argc, char ** argv) {
    int i, oldRank, oldSize;
    int newRank, newSize;
    int ranks1[DIM], ranks2[DIM];
    MPI_Group commGroup, newGroup;
    MPI_Comm newComm;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &oldRank);
    MPI_Comm_size (MPI_COMM_WORLD, &oldSize);
    if (oldSize!=2*DIM) {
        if (oldRank==0)
            printf ("Invalid process number.\n");
        MPI_Finalize ();
        return (-1); }
    for (i=0;i<DIM;i++) {
        ranks1[i] = 2*i;
        ranks2[i] = 2*i+1; }
    MPI_Comm_group (MPI_COMM_WORLD, &commGroup);
    if (!(oldRank%2))
        MPI_Group_incl (commGroup, DIM, ranks1, &newGroup);
    else
        MPI_Group_incl (commGroup, DIM, ranks2, &newGroup);
    MPI_Comm_create (MPI_COMM_WORLD, newGroup, &newComm);
    MPI_Comm_rank (newComm, &newRank);
    MPI_Comm_size (newComm, &newSize);
    if (newRank==0) {
        printf ("MPI_COMM_WORLD Communicator is associated \
                 with %d processes\n", oldSize);
        printf ("newComm Communicator is associated with %d \
                 processes\n",    newSize); }
        printf ("Process Rank in MPI_COMM_WORLD: %d ==> Process Rank \
                 in newComm: %d\n", oldRank, newRank);
    MPI_Group_free (&newGroup);
    MPI_Comm_free (&newComm);
    MPI_Finalize();
    return (0); }
    
    
    
    
