/* Source File Slave.c */

#include <mpi.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int rank, size, counter;
    MPI_Comm interComm;
    MPI_Status status;
    int rows, columns;
    double * data, * local, mean;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Comm_get_parent (&interComm);
    if (interComm==MPI_COMM_NULL) {
        printf ("Parent Comm does not exists...\n");
        MPI_Abort (MPI_COMM_WORLD, -1); }
    if (rank==0) {
        MPI_Recv (&rows, 1, MPI_DOUBLE, 0, 0, 
                  interComm, &status);
        MPI_Recv (&columns, 1, MPI_DOUBLE, 0, 0, 
                  interComm, &status);
        printf ("Slave %02d received from master process \
                 %02d rows and %02d columns\n", 
                 rank, rows, columns);
        data = (double *) malloc (rows*columns*sizeof(double));
        MPI_Recv (data, rows*columns, MPI_DOUBLE, 0, 0,
                  interComm, &status); }
    MPI_Bcast (&columns, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    local = (double *) malloc (columns*sizeof(double));
    MPI_Scatter (data, columns, MPI_DOUBLE, local, columns,
                 MPI_DOUBLE, 0, MPI_COMM_WORLD);
    printf ("Slave %02d local data : ", rank);
    for (counter=0;counter<columns;counter++)
         printf ("%.3f ", local[counter]);
    printf ("\n");
    if (rank==0) free (data);
    mean = 0.0;
    for (counter=0;counter<columns;counter++)
         mean += local[counter];
    mean /= columns;
    printf ("Slave %02d estimated a mean of %.9f\n",
            rank, mean);
    free (local);
    MPI_Finalize();
    return 0; }
    
    
    
    
