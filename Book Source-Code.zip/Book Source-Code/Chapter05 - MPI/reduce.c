#include <mpi.h>
#include <math.h>
#include <stdio.h>


double func (double x) {
    return (4/(1+pow(x,2))); }

double CalcIntegral (double a, double b, 
                     int N, double base) {
    double x, integral;
    int i;
    integral = (func(a)+func(b))/2.0;
    x = a;
    for (i=1;i<=N-1;i++) {
         x = x+base;
         integral = integral + func(x); }
    integral = integral * base;
    return (integral); }

int main(int argc, char* argv[]) {
    int rank, size;
    double a=0.0, b=1.0;
    unsigned long N = 1000000;
    double base = (b-a)/N;
    double localA, localB;
    int localN;
    double localIntegral=0.0;
    double totalIntegral=0.0;
    int messageTag=0;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    localN = N/size;
    localA=a+rank*localN*base;
    localB=localA+localN*base;
    localIntegral = CalcIntegral (localA, localB, localN, base);
    printf ("Process %d: a=%.3f b=%.3f Trapezoids=%d integral=%.3f\n", 
             rank, localA, localB, localN, localIntegral);
    MPI_Reduce(&localIntegral,&totalIntegral,1,MPI_DOUBLE,
               MPI_SUM, 0, MPI_COMM_WORLD);
    if (rank==0)
        printf ("%ld trapezoids used ==> integral value is %.8f\n", 
                 N, totalIntegral);
    MPI_Finalize();
    return 0; }
    
    
    
