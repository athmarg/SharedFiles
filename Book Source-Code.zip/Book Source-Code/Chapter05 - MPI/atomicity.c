#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define LENGTH 1024

int main (int argc, char ** argv) {
    int counter, rank, size;
    char fileName[64]="samples.dat";
    int readBuffer[LENGTH];
    int writeBuffer[LENGTH];
    MPI_File fileHandle;
    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    for (counter=0;counter<LENGTH;counter++)
         writeBuffer [counter] = 0;
    if (rank==0) {
        MPI_File_open (MPI_COMM_SELF, fileName,
                 MPI_MODE_CREATE | MPI_MODE_RDWR,
                 MPI_INFO_NULL, &fileHandle);
        MPI_File_write (fileHandle, writeBuffer, 
                 LENGTH, MPI_INT, &status);
        MPI_File_close (&fileHandle); }
    for (counter=0;counter<LENGTH;counter++) {
         writeBuffer[counter] = 100;
         readBuffer[counter] = 200; }
    MPI_Barrier (MPI_COMM_WORLD);
    MPI_File_open (MPI_COMM_WORLD, fileName, 
             MPI_MODE_RDWR, MPI_INFO_NULL, 
             &fileHandle);
    MPI_File_set_atomicity (fileHandle, true);
    MPI_Barrier (MPI_COMM_WORLD);
    if (rank==0)
        MPI_File_write (fileHandle, writeBuffer, 
                 LENGTH, MPI_INT, &status);
    else {
        MPI_File_read (fileHandle, readBuffer, 
                 LENGTH, MPI_INT, &status);
        printf ("Process %02d data values: ", rank);
        for (counter=0;counter<5;counter++)
             printf ("%d ", readBuffer[counter]);
        printf ("\n");
        if (readBuffer[0]==0) {
          for (counter=1;counter<LENGTH;counter++) {
             if (readBuffer[counter]!=0) {
                 printf ("Process %02d: readBuffer[%02d] \
                          is %02d instead of 0\n", 
                          rank, counter, readBuffer[counter]);
                 MPI_Abort (MPI_COMM_WORLD, 1); }}}
        else if (readBuffer[0]==100){
             for (counter=1;counter<LENGTH;counter++) {
                if (readBuffer[counter]!=100) {
                    printf ("Process %02d: readBuffer[%02d] \
                             is %02d instead of 0\n",
                            rank, counter, readBuffer[counter]);
                    MPI_Abort (MPI_COMM_WORLD, 1); }}}
        else
             printf ("Process %02d: readBuff[0] is %d instead \
                      of 0 or 100\n", rank, readBuffer[0]); }
    MPI_File_close (&fileHandle);
    MPI_Finalize();
    return (0); }
