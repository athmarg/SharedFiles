#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM 4
#define Swap(x,y) { \
        double * temp; temp = x; \
        x = y; y = temp; }

double Distance (double * x, double * y, int N) { 
    int counter;
    double dist = 0.0; 
    for (counter=0;counter<N;counter++)
         dist += pow((x[counter]-y[counter]),2);
    return (sqrt(dist)); }

int main (int argc, char ** argv) {
    int rank, size; double matrix[DIM][DIM];
    double tol, bCol[DIM];
    int counter, index, cycles, items, loop;
    double * bLocal, * xLocal; double * aLocal;
    double temp[DIM], dummy[DIM]; double * xOld, * xNew;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (DIM%size) {
        if (rank==0)
            printf ("Invalid Process Number...\n");
        MPI_Finalize();
        return (-1); }
    items = DIM/size;
    aLocal = (double *)malloc(items*DIM*sizeof(double));
    bLocal = (double *)malloc(items*sizeof(double));
    xLocal = (double *)malloc(items*sizeof(double));
    if (rank==0) {
        cycles = 1000;
        tol = 0.0000001;
        bCol[0] = 7; bCol[1]= -1;
        bCol[2] = -5; bCol[3]= 2;
        matrix[0][0] = 10; matrix[0][1] = 1;
        matrix[0][2] = 1; matrix[0][3] = 1;
        matrix[1][0] = 3; matrix[1][1] = 5;
        matrix[1][2] = 0; matrix[1][3] = -1;
        matrix[2][0] = 2; matrix[2][1] = -1;
        matrix[2][2] = 10; matrix[2][3] = -2;
        matrix[3][0] = 0; matrix[3][1] = 3;
        matrix[3][2] = 0; matrix[3][3] = -5; }
    MPI_Bcast (&cycles, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&tol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Scatter (bCol, items, MPI_DOUBLE, bLocal, items,
                 MPI_DOUBLE, 0, MPI_COMM_WORLD); 
    MPI_Scatter (&matrix, items*DIM, MPI_DOUBLE, aLocal,
                 items*DIM, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Allgather (bLocal, items, MPI_DOUBLE, temp, items,
                   MPI_DOUBLE, MPI_COMM_WORLD);
    xNew = temp; xOld = dummy;
    loop = 0;
    do {
         loop++;
         Swap (xOld, xNew);
         for (counter=0;counter<items;counter++) {
              xLocal[counter]=bLocal[counter];
              for (index=0;index<DIM;index++)
                   if (index!=(counter+rank*items))
                       xLocal[counter]-=
                              aLocal[counter*DIM+index]*
                                     xOld[index];
              xLocal[counter]/= aLocal[counter*DIM+counter+
                                       rank*items]; }
         MPI_Allgather (xLocal, items, MPI_DOUBLE, xNew, 
                        items, MPI_DOUBLE, MPI_COMM_WORLD);
       } while ((loop<cycles)&&
                (Distance(xOld, xNew, DIM)>tol));
    if (Distance(xOld, xNew, DIM)<=tol) {
    if (rank==0) {
        printf ("System Solution : ");
        for (counter=0;counter<DIM;counter++)
             printf ("%.3f ", xNew[counter]);
        printf ("\n"); }}
    else {
           if (rank==0)
               printf ("No solution !!! \n"); }
    free (aLocal);
    free (bLocal);
    free (xLocal);
    MPI_Finalize();
    return (0); }
    
    
    

