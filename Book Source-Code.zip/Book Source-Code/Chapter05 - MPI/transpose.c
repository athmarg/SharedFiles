#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ROWS 10
#define COLS  8

int main (int argc, char ** argv) {
    int i, j, rank, size; long int extent;
    double aMatrix[ROWS][COLS];
    double bMatrix[COLS][ROWS];

    MPI_Datatype colType, matType;
    MPI_Status status;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);

    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number.Aborting.\n");
        MPI_Finalize();
        return (-1); }

    MPI_Type_vector (ROWS, 1, COLS, MPI_DOUBLE, &colType);
    MPI_Type_commit (&colType);

    MPI_Type_extent (MPI_DOUBLE, &extent);

    MPI_Type_hvector (COLS,1,extent,colType,&matType);
    MPI_Type_commit (&matType);

    for (i=0;i<ROWS;i++) {
        for (j=0;j<COLS;j++) {
             aMatrix[i][j]=(double)rand()/RAND_MAX;
             bMatrix[j][i]=0.0; }}

    if (rank==0) {
        printf ("MATRIX A ELEMENTS\n");
        for (i=0;i<ROWS;i++) {
             printf ("\n");
             for (j=0;j<COLS;j++) {
                  printf ("%.3f ", aMatrix[i][j]); }}

        MPI_Send (&aMatrix[0][0],1,matType,1,0,
            MPI_COMM_WORLD); }
    else {
        MPI_Recv (&bMatrix[0][0],ROWS*COLS,MPI_DOUBLE,
                  0,0, MPI_COMM_WORLD, &status);

        printf ("\nMATRIX B ELEMENTS\n");
        for (i=0;i<COLS;i++) {
             printf ("\n");
             for (j=0;j<ROWS;j++) {
                  printf ("%.3f ",bMatrix[i][j]); }}}

    MPI_Type_free (&colType);
    MPI_Type_free (&matType);
    MPI_Finalize ();
    return (0); }
