#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define NEURONS 3
#define LINKS 8

#define SIGMOIDAL 0
#define IDENTITY 1

typedef struct Neuron {
 int neuronId, layerId;
 double threshold;
 int functionType;
 double inputs [LINKS], weights [LINKS]; } Neuron;

Neuron sourceLayer [NEURONS], targetLayer [NEURONS];
double inputVector [LINKS] = {0.250,0.375,0.020,0.005,
                              0.975,0.543,0.125,0.0075};

void InitLayer (void) {
 int i, j;
 for (i=0;i<NEURONS;i++) {
   sourceLayer[i].layerId = 1;
   sourceLayer[i].neuronId = i;
   sourceLayer[i].threshold = (double)rand()/RAND_MAX;
   sourceLayer[i].functionType = SIGMOIDAL;
   for (j=0;j<LINKS;j++) {
    sourceLayer[i].inputs[j] = inputVector[j];
    sourceLayer[i].weights[j] =
      (double)rand()/RAND_MAX; }}}

int main (int argc, char ** argv) {
    int i, j, rank, size; long int start;
    double sum, output;
    int blockLength [] = {1, 1, 1, 1, LINKS, LINKS};
    MPI_Datatype dataTypes [] = {
                 MPI_INT, MPI_INT, MPI_DOUBLE, MPI_INT, 
                 MPI_DOUBLE, MPI_DOUBLE};
    MPI_Aint dispArray[6];
    MPI_Datatype neuronType;
    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number. Aborting...\n");
        MPI_Finalize();
        return (-1); }
    InitLayer ();
    MPI_Address (&sourceLayer[0].neuronId, &dispArray[0]);
    MPI_Address (&sourceLayer[0].layerId, &dispArray[1]);
    MPI_Address (&sourceLayer[0].threshold, &dispArray[2]);
    MPI_Address (&sourceLayer[0].functionType, &dispArray[3]);
    MPI_Address (&sourceLayer[0].inputs, &dispArray[4]);
    MPI_Address (&sourceLayer[0].weights, &dispArray[5]);
    start = dispArray[0];
    for (i=0;i<6;i++) dispArray[i] -= start;
    MPI_Type_struct (6,blockLength,dispArray,dataTypes,&neuronType);
    MPI_Type_commit (&neuronType);
    if (rank==0) 
        MPI_Send (sourceLayer,NEURONS,neuronType, 1, 0, MPI_COMM_WORLD);
    else {
           MPI_Recv (targetLayer, NEURONS, neuronType, 0, 0, 
                     MPI_COMM_WORLD, &status);
           printf ("\nLayer Configuration\n");
           printf ("-------------------\n\n");
           for (i=0;i<NEURONS;i++) {
                printf ("Neuron %02d --> NeuronId = %02d\n", 
                         i, targetLayer[i].neuronId);
                printf ("Neuron %02d --> LayerId = %02d\n",  
                         i, targetLayer[i].layerId);
                printf ("Neuron %02d --> Threshold = %.3f\n", 
                         i, targetLayer[i].threshold);
                if (targetLayer[i].functionType==SIGMOIDAL) 
                    printf ("Neuron %02d --> Function = SIGMOIDAL\n", i);
                if (targetLayer[i].functionType==IDENTITY)
                    printf ("Neuron %02d --> Function = IDENTITY\n", i);
                printf ("Neuron %02d --> Inputs = ", i);
                for (j=0;j<LINKS;j++)
                     printf ("%.2f ", targetLayer[i].inputs[j]);
                printf ("\n");
                printf ("Neuron %02d --> Weights = ", i);
                for (j=0;j<LINKS;j++)
                     printf ("%.2f ", targetLayer[i].weights[j]);
                printf ("\n\n"); }
           printf ("\nLayer Output\n");
           printf ("-------------------\n\n");
           for (i=0;i<NEURONS;i++) {
                sum = 0.0, output = 0.0;
                for (j=0;j<LINKS;j++)
                     sum += targetLayer[i].inputs[j]*
                            targetLayer[i].weights[j];
                sum -= targetLayer[i].threshold;
                if (targetLayer[i].functionType==IDENTITY) output = sum;
                if (targetLayer[i].functionType==SIGMOIDAL) 
                    output = 1/(1+exp(-sum));
                printf ("Neuron %02d --> Output = %.6f\n", i, output); }}

    MPI_Type_free (&neuronType);
    MPI_Finalize ();
    return (0); }
    
    
    
    
