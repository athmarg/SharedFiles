#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct RGBStruct {
    unsigned char red;
    unsigned char green;
    unsigned char blue;
    } RGBStruct;

#define COLORS 256

int main (int argc, char ** argv) {
    int i, rgbSize; long int rgbExtent;
    int rank, size, blocks, items;
    MPI_Datatype rgbType;
    RGBStruct sendPalette [COLORS];
    RGBStruct recvPalette [COLORS];
    MPI_Status status;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);

    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number. Aborting...\n");
        MPI_Abort (MPI_COMM_WORLD, -1); }

    MPI_Type_contiguous (3, MPI_UNSIGNED_CHAR, &rgbType);
    MPI_Type_commit (&rgbType);
    MPI_Type_size (rgbType, &rgbSize);
    MPI_Type_extent (rgbType, &rgbExtent);

    if (rank==0) {
      for (i=0;i<COLORS;i++) {
       sendPalette[i].red=
          (int)(COLORS*((double)rand()/RAND_MAX));
       sendPalette[i].green=
          (int)(COLORS*((double)rand()/RAND_MAX));
       sendPalette[i].blue=
          (int)(COLORS*((double)rand()/RAND_MAX)); }

       MPI_Send (sendPalette,COLORS,rgbType,1,0,MPI_COMM_WORLD);
       printf ("Process 0 sent a gray scale color palette\n"); }

    if (rank==1) {
      MPI_Recv (recvPalette,COLORS,rgbType,0,0,
                MPI_COMM_WORLD,&status);
      MPI_Get_count (&status, rgbType, &blocks);
      MPI_Get_elements (&status, rgbType, &items);

      printf ("Process %02d received %d blocks and %d items\n", 
               rank, blocks, items);
      printf ("Printing 10 first colors...\n");
      for (i=0;i<10;i++)
           printf ("Color%02d===>Red:%03d Green:%03d Blue:%03d\n",
                   i, recvPalette[i].red, recvPalette[i].green,
                   recvPalette[i].blue);
      for (i=0;i<COLORS;i++)
            recvPalette[i].red=recvPalette[i].green=
                recvPalette[i].blue=(int)((recvPalette[i].red+
                recvPalette[i].green+recvPalette[i].blue)/3);

      MPI_Send (recvPalette,COLORS,rgbType,0,0,MPI_COMM_WORLD); }

    if (rank==0) {
      MPI_Recv (sendPalette,COLORS,rgbType,1,0,
                MPI_COMM_WORLD,&status);
      printf ("Gray scale color palette received\n");
      printf ("Printing 10 first colors...\n");
      for (i=0;i<10;i++)
           printf ("Color%02d=>Red:%03d Green:%03d Blue:%03d\n",
                   i, sendPalette[i].red, sendPalette[i].green,
                      sendPalette[i].blue); }

    MPI_Type_free (&rgbType);
    MPI_Finalize();
    return (0); }
    
    
    
    
    
    
    
