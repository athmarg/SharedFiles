#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 8
#define STRIDE 8

int main (int argc, char ** argv) {
    int i, j, rank, size, root = 0;
    double aMatrix[DIM][DIM];
    double * sendPtr, * recvBuffer;
    int * displacements, * sendCounts;
    double localSum = 0.0, totalSum = 0.0;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (size!=DIM) {
        if (rank==0)
            printf ("Invalid process number.\n");
        MPI_Finalize();
        return (-1); }
    for (i=0;i<DIM;i++) {
         for (j=0;j<DIM;j++) {
              aMatrix[i][j]=
                     (double)rand()/RAND_MAX; }}
    recvBuffer=(double *)
                malloc((DIM-rank)*sizeof(double));
    if (!recvBuffer) {
        if (rank==0)
            printf ("Not enough memory ...\n");
        MPI_Finalize();
        return (-2); }
    for (i=0;i<(DIM-rank);i++) recvBuffer[i]=-1;        
    displacements = (int *) malloc (size*sizeof(int));
    if (!displacements) {
        if (rank==0)
            printf ("Not enough memory ...\n");
        MPI_Finalize();
        return (-2); }
    sendCounts = (int *) malloc (size*sizeof(int));
    if (!sendCounts) {
        if (rank==0)
            printf ("Not enough memory ...\n");
        MPI_Finalize();
        return (-2); }
    for (i=0;i<size;i++) {
         displacements[i] = i*STRIDE+i;
         sendCounts[i] = DIM-i; }
    sendPtr = &aMatrix[rank][rank];
    MPI_Scatterv (sendPtr, sendCounts, 
        displacements,MPI_DOUBLE, recvBuffer, 
        DIM-rank, MPI_DOUBLE, root, MPI_COMM_WORLD);
    for (i=0;i<DIM-rank;i++) 
         localSum += recvBuffer[i];
    printf ("Sum of process %d is %f\n", 
             rank, localSum);
    MPI_Reduce(&localSum, &totalSum, 1, 
               MPI_DOUBLE, MPI_SUM, 0, 
               MPI_COMM_WORLD);
    if (rank==0) 
        printf ("Total Sum is %f\n", totalSum);
    free (displacements);
    free (sendCounts);
    free (recvBuffer);
    MPI_Finalize ();
    return (0); }
    
    
    
    
    
    
    
