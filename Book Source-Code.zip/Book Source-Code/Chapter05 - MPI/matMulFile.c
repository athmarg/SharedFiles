#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM 8
#define NODES 4
#define SLICE DIM/NODES

int main (int argc, char ** argv) {
   int rank, size; long int extent;
   int counter, cnt, index, retVal, x;
   int blockLength, blockExtent, rowExtent;
   MPI_Datatype columnBType, blockCType;
   MPI_Datatype fileTypeA;
   MPI_Datatype fileTypeB, fileTypeC;
   MPI_File fileHandleA;
   MPI_File fileHandleB, fileHandleC;
   MPI_Status status;
   int blockLengthsA [3], blockLengthsB [3];
   int blockLengthsC [3];
   MPI_Aint displacementsA [3];
   MPI_Aint displacementsB [3];
   MPI_Aint displacementsC [3];
   MPI_Datatype typesA [3];
   MPI_Datatype typesB [3], typesC [3];
   double matA [SLICE][DIM];
   double matB [DIM][SLICE];
   double matC [SLICE][SLICE];
   double matrix [DIM][DIM];
   MPI_Init (&argc, &argv);
   MPI_Comm_rank (MPI_COMM_WORLD, &rank);
   MPI_Comm_size (MPI_COMM_WORLD, &size);
   if (size!=NODES) {
       printf ("Invalid Process Number\n");
       MPI_Finalize();
       return (-1); }
   if (rank==0) {
       for (counter=0;counter<DIM;counter++)
            for (index=0;index<DIM;index++)
                 matrix[counter][index]=(double)rand()/RAND_MAX;
       printf ("Matrix A contents\n");
       for (counter=0;counter<DIM;counter++) {
            for (index=0;index<DIM;index++)
                 printf ("%.3f ", matrix[counter][index]);
             printf ("\n");}
       MPI_File_open (MPI_COMM_SELF, "fileA.dat", MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandleA);
       MPI_File_write_at (fileHandleA, 0, matrix, DIM*DIM, MPI_DOUBLE, &status);
       MPI_File_close (&fileHandleA);
       for (counter=0;counter<DIM;counter++)
            for (index=0;index<DIM;index++)
                 matrix[counter][index]=(double)rand()/RAND_MAX;
       printf ("\n"); 
       printf ("Matrix B contents\n");
       for (counter=0;counter<DIM;counter++) {
            for (index=0;index<DIM;index++)
                 printf ("%.3f ", matrix[counter][index]);
       printf ("\n");}
       MPI_File_open (MPI_COMM_SELF, "fileB.dat",
       MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandleB);
       MPI_File_write_at (fileHandleB, 0, matrix, DIM*DIM, MPI_DOUBLE, &status);
       MPI_File_close (&fileHandleB); }
   MPI_Type_extent (MPI_DOUBLE, &extent);
   blockLength = DIM*SLICE;
   blockExtent = blockLength*extent;
   blockLengthsA[0]=1; 
   blockLengthsA[1]=blockLength;
   blockLengthsA[2]=1;
   displacementsA[0]=0;
   displacementsA[1]=blockExtent*rank;
   displacementsA[2]=blockExtent*NODES;
   typesA[0]=MPI_LB;
   typesA[1]=MPI_DOUBLE;
   typesA[2]=MPI_UB;
   MPI_Type_struct (3, blockLengthsA, displacementsA, typesA, &fileTypeA);
   MPI_Type_commit (&fileTypeA);
   rowExtent = SLICE*extent;
   MPI_Type_vector (DIM, SLICE, DIM, MPI_DOUBLE, &columnBType);
   blockLengthsB[0]=1;
   blockLengthsB[1]=1;
   blockLengthsB[2]=1;
   displacementsB[0]=0;
   displacementsB[2]=rowExtent*NODES;
   typesB[0]=MPI_LB;
   typesB[1]=columnBType;
   typesB[2]=MPI_UB;
   MPI_Type_vector (SLICE, SLICE, DIM, MPI_DOUBLE, &blockCType);
   blockLengthsC[0]=1;
   blockLengthsC[1]=1;
   blockLengthsC[2]=1;
   displacementsC[0]=0;
   displacementsC[2]=blockExtent*NODES; 
   typesC[0]=MPI_LB;
   typesC[1]=blockCType;
   typesC[2]=MPI_UB;
   retVal = MPI_File_open (MPI_COMM_WORLD, "fileA.dat", MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandleA);
   if (retVal!=MPI_SUCCESS) {
       printf ("File could not be opened\n");
       MPI_Finalize(); 
       return (-1); }
   MPI_File_set_view (fileHandleA, 0, MPI_DOUBLE, fileTypeA, "native", MPI_INFO_NULL);
   MPI_File_read (fileHandleA, matA, DIM*SLICE, MPI_DOUBLE, &status);
   retVal = MPI_File_open (MPI_COMM_WORLD, "fileB.dat", MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandleB);
   if (retVal!=MPI_SUCCESS) {
       printf ("File could not be opened\n");
       MPI_Finalize(); 
       return (-1); }
   retVal = MPI_File_open (MPI_COMM_WORLD, "fileC.dat", MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandleC);
   if (retVal!=MPI_SUCCESS) {
       printf ("File could not be opened\n");
       MPI_Finalize(); 
       return (-1); }
   for (counter=0;counter<NODES;counter++) {
        displacementsB[1]=rowExtent*counter;
        MPI_Type_struct (3, blockLengthsB, displacementsB, typesB, &fileTypeB);
        MPI_Type_commit (&fileTypeB);
        MPI_File_set_view (fileHandleB, 0, MPI_DOUBLE, fileTypeB,"native", MPI_INFO_NULL);
        MPI_File_read (fileHandleB, matB, DIM*SLICE, MPI_DOUBLE, &status);
        MPI_Type_free (&fileTypeB);
        for (cnt=0;cnt<SLICE;cnt++) {
             for (index=0;index<SLICE;index++) {
                  matC [cnt][index]=0.0;
                  for (x=0;x<DIM;x++) {
                       matC[cnt][index] += matA[cnt][x]*matB[x][index]; }}}
        displacementsC[1]=blockExtent*rank+rowExtent*counter;
        MPI_Type_struct (3, blockLengthsC, displacementsC, typesC, &fileTypeC);
        MPI_Type_commit (&fileTypeC);
        MPI_File_set_view (fileHandleC, 0, MPI_DOUBLE, fileTypeC, "native", MPI_INFO_NULL);
        MPI_File_write (fileHandleC, matC, SLICE*SLICE, MPI_DOUBLE, &status);
        MPI_Type_free (&fileTypeC); }
   MPI_Type_free (&fileTypeA);
   MPI_File_close (&fileHandleA);
   MPI_File_close (&fileHandleB);
   MPI_File_close (&fileHandleC);
   if (rank==0) {
      retVal = MPI_File_open (MPI_COMM_SELF, "fileC.dat", MPI_MODE_RDONLY, MPI_INFO_NULL, &fileHandleC);
      if (retVal!=MPI_SUCCESS) {
          printf ("File could not be opened\n");
          MPI_Finalize();
          return (-1); }
      MPI_File_read (fileHandleC, matrix, DIM*DIM, MPI_DOUBLE, &status);
      printf ("\nResult matrix C contents\n");
      for (counter=0;counter<DIM;counter++) {
           for (index=0;index<DIM;index++)
                printf ("%.3f ", matrix[counter][index]);
       printf ("\n"); }
       MPI_File_close (&fileHandleC); }
   MPI_Type_free (&columnBType);
   MPI_Type_free (&blockCType);
   MPI_Finalize (); 
   return (0); }
   
   
