#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char ** argv) {
    int rank, size, length, data, * buffer;
    char fileName[16]="data.txt";
    MPI_File fileHandle;
    MPI_Status status;
    MPI_Offset fileSize;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (rank==0) {
        MPI_File_open (MPI_COMM_SELF, fileName,
                 MPI_MODE_RDONLY, MPI_INFO_NULL, &fileHandle);
        MPI_File_get_size (fileHandle, &fileSize);
        MPI_File_close (&fileHandle);
        length = (int)(fileSize/size);
        data = (int)(length/sizeof(int)); }
    MPI_Bcast (&fileSize, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&length, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&data, 1, MPI_INT, 0, MPI_COMM_WORLD);
    buffer = (int *) malloc (data*sizeof(int));
    if (!buffer) {
        printf ("No memory available\n");
        MPI_Finalize();
        return (-1); }
    MPI_File_open (MPI_COMM_WORLD, fileName, MPI_MODE_RDWR, 
                   MPI_INFO_NULL, &fileHandle);
    MPI_File_seek (fileHandle, rank*length, MPI_SEEK_SET);
    MPI_File_read (fileHandle, buffer, data, MPI_INT,  &status);
    MPI_File_close (&fileHandle);
    for (int i=0;i<5;i++)
         printf ("Process %d --> buffer [%d] = %02d\n",
                 rank, i, buffer[i]);
    printf ("\n");
    free (buffer);
    MPI_Finalize ();
    return (0); }
    
    
