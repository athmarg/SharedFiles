#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char* argv[]) {
    int rank, size, dVal = 100;
    MPI_Request request; MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size!=2) {
        printf("This application requires exactly two processes to run\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE); }
    if (rank==0) {   
        MPI_Send_init(&dVal, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &request);
        MPI_Start(&request);
        printf("Process %d sends value %d\n", rank, dVal); }
    if (rank==1) {
        MPI_Recv(&dVal, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        printf("Process %d received value %d\n", rank, dVal); }
    MPI_Finalize();
    return (0); }
    
    
