#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM 4
#define TAG 100


double Distance (double * x, double * y, int N) {
    int counter; double dist = 0.0;
    for (counter=0;counter<N;counter++)
         dist += pow((x[counter]-y[counter]),2);
    return (sqrt(dist)); }

int main (int argc, char ** argv) {
    int rank, targetRank, size, items, offset;
    double matrix[DIM][DIM];
    double tol, bCol[DIM];
    int doubleSize;
    int counter, index, cycles, loop;
    double * aLocal, * bLocal, * xLocal;
    double temp[DIM], xNew[DIM];
    double xOld[DIM];
    int * ranks;
    double distance;
    MPI_Status status;
    MPI_Win xOldWin, xNewWin;
    MPI_Group commGroup;
    MPI_Group originGroup, targetGroup;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Comm_group(MPI_COMM_WORLD, &commGroup);
    if (DIM%(size-1)) {
        printf ("Invalid Process Number...\n");
        MPI_Abort (MPI_COMM_WORLD, -1); }
    items = DIM/(size-1);
    MPI_Type_size (MPI_DOUBLE, &doubleSize);
    aLocal = (double *)malloc(items*DIM*sizeof(double));
    bLocal = (double *)malloc(items*sizeof(double));
    xLocal = (double *)malloc(items*sizeof(double));
    if (rank==0) {
        cycles = 100;
        tol = 0.0000001;
        bCol[0] =  7; bCol[1]= -1;
        bCol[2] = -5; bCol[3]=  2;
        matrix[0][0] = 10; matrix[0][1] =  1;
        matrix[0][2] =  1; matrix[0][3] =  1;
        matrix[1][0] =  3; matrix[1][1] =  5;
        matrix[1][2] =  0; matrix[1][3] = -1;
        matrix[2][0] =  2; matrix[2][1] = -1;
        matrix[2][2] = 10; matrix[2][3] = -2;
        matrix[3][0] =  0; matrix[3][1] =  3;
        matrix[3][2] =  0; matrix[3][3] = -5;
        loop = 0;
        for (counter=0;counter<items;counter++) {
             bLocal[counter]=bCol[counter];
             for (index=0;index<DIM;index++) {
                  aLocal[loop]=matrix[counter][index];
                  loop++; }}
        offset = items;
        for (counter=1;counter<(size-1);counter++) {
             MPI_Send(&matrix[offset][0], items*DIM, MPI_DOUBLE,
                      counter, TAG, MPI_COMM_WORLD);
             MPI_Send (&bCol[offset], items, MPI_DOUBLE,
                       counter, TAG, MPI_COMM_WORLD);
             offset += items; }}
    else {
        if (rank<(size-1)) {
            MPI_Recv (aLocal, items*DIM, MPI_DOUBLE, 0, TAG,
                      MPI_COMM_WORLD, &status);
            MPI_Recv (bLocal, items, MPI_DOUBLE, 0, TAG,
                      MPI_COMM_WORLD, &status); }}
    MPI_Bcast (&cycles, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast (&tol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    if (rank==(size-1)) {
        MPI_Win_create (temp, DIM*doubleSize, doubleSize,
            MPI_INFO_NULL, MPI_COMM_WORLD, &xOldWin);
        MPI_Win_create (xNew, DIM*doubleSize, doubleSize,
            MPI_INFO_NULL, MPI_COMM_WORLD, &xNewWin); }
    else {
        MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
            MPI_COMM_WORLD, &xOldWin);
        MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
            MPI_COMM_WORLD, &xNewWin); }
    ranks = (int *) malloc ((size-1)*sizeof(int));
    for (counter=0;counter<(size-1);counter++)
         ranks[counter]=counter;
    MPI_Group_incl (commGroup, (size-1), ranks, &originGroup);
    targetRank=size-1;
    MPI_Group_incl (commGroup, 1, &targetRank, &targetGroup);
    if (rank==(size-1)) {
        MPI_Win_post (originGroup, 0, xOldWin);
        MPI_Win_wait (xOldWin); }
    else {
        MPI_Win_start (targetGroup, 0, xOldWin);
        MPI_Put (bLocal, items, MPI_DOUBLE, (size-1),
            rank*items, items, MPI_DOUBLE, xOldWin);
        MPI_Win_complete (xOldWin); }
    loop = 0;
    do {
      loop++;
      if (rank<(size-1)) {
          MPI_Win_start (targetGroup, 0, xOldWin);
          MPI_Get (xOld, DIM, MPI_DOUBLE, (size-1),
                   0, DIM, MPI_DOUBLE, xOldWin);
          MPI_Win_complete (xOldWin);  }
      else {
          MPI_Win_post (originGroup, 0, xOldWin);
          MPI_Win_wait (xOldWin); }
      if (rank<(size-1)) {
        for (counter=0;counter<items;counter++) {
          xLocal[counter]=bLocal[counter];
          for (index=0;index<DIM;index++)
             if (index!=(counter+rank*items))
                xLocal[counter]-=
                    aLocal[counter*DIM+index]*xOld[index];
          xLocal[counter] /=
              aLocal[counter*DIM+counter+rank*items]; }
        MPI_Win_start (targetGroup, 0, xNewWin);
        MPI_Put (xLocal, items, MPI_DOUBLE, (size-1),
            rank*items, items, MPI_DOUBLE, xNewWin);
        MPI_Win_complete (xNewWin); }
      else {
         MPI_Win_post (originGroup, 0, xNewWin);
         MPI_Win_wait (xNewWin);
         distance = Distance (xNew, temp, DIM);
         for (counter=0;counter<DIM;counter++)
              temp[counter]=xNew[counter]; }
      MPI_Bcast (&distance, 1, MPI_DOUBLE, size-1,
               MPI_COMM_WORLD);
       } while ((loop<cycles)&&(distance>tol));
    if (distance<=tol) {
        if (rank==size-1) {
            printf ("System Solution ");
            for (counter=0;counter<DIM;counter++)
                 printf ("%.3f ", xNew[counter]);
            printf ("has been reached after %d iterations\n",
                    loop);
            printf ("\n"); }}
    else {
        if (rank==size-1)
            printf ("No solution available\n"); }
    free (aLocal);
    free (bLocal);
    free (xLocal);
    free (ranks);
    MPI_Group_free (&originGroup);
    MPI_Group_free (&targetGroup);
    MPI_Win_free (&xOldWin);
    MPI_Win_free (&xNewWin);
    MPI_Finalize();
    return (0); }
