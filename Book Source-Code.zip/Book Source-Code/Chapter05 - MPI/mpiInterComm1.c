#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char ** argv) {
   int rank, key, a=10, b=0;
   MPI_Comm intraComm;
   MPI_Comm interComm1, interComm2;
   MPI_Init (&argc, &argv);
   MPI_Comm_rank (MPI_COMM_WORLD, &rank);
   key = rank%3;
   MPI_Comm_split (MPI_COMM_WORLD, key, rank, &intraComm);
   if (key==0)
       MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, 1, 01, &interComm1);
   else if (key==1) {
        MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, 0, 01, &interComm1);
        MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, 2, 12, &interComm2); }
   else if (key==2)
   MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, 1, 12, &interComm1);
   // ..........................................................................
   // Additional code can be inserted between these dotted lines
   // ..........................................................................
   MPI_Comm_free (&intraComm);
   MPI_Comm_free (&interComm1);
   if (key==1) MPI_Comm_free (&interComm2);
   MPI_Finalize ();
   return (0); }
