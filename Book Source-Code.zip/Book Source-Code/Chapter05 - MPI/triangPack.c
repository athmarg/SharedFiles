#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 8
#define BUFSIZE (DIM*(DIM+1)/2)*sizeof(double)

int main (int argc, char ** argv) {
    int i, j, rank, size, packPosition;
    double aMatrix[DIM][DIM];
    double bMatrix[DIM][DIM];
    char packBuffer[BUFSIZE];
    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number.\n");
        MPI_Finalize();
        return (-1); }
    for (i=0;i<DIM;i++) {
         for (j=0;j<DIM;j++) {
              aMatrix[i][j]=(double)rand()/RAND_MAX;
              bMatrix[i][j]=0.0; }}
    if (rank==0) {
        printf ("MATRIX A ELEMENTS\n");
        for (i=0;i<DIM;i++) {
             printf ("\n");
             for (j=0;j<DIM;j++) {
                  printf ("%.3f ", aMatrix[i][j]); }}
        packPosition = 0;
        for (i=0;i<DIM;i++) {
             for (j=i;j<DIM;j++) {
                  MPI_Pack (&aMatrix[i][j], 1, MPI_DOUBLE,
                      packBuffer,BUFSIZE, &packPosition,
                      MPI_COMM_WORLD); }}
        MPI_Send (packBuffer, packPosition,MPI_PACKED,
                  1,0,MPI_COMM_WORLD); }
    else {
        MPI_Recv (packBuffer, BUFSIZE, MPI_PACKED, 0, 0,
                  MPI_COMM_WORLD, &status);
        packPosition = 0;
        for (i=0;i<DIM;i++) {
             for (j=i;j<DIM;j++) {
                  MPI_Unpack (packBuffer,BUFSIZE,&packPosition,
                      &bMatrix[i][j],1,MPI_DOUBLE,
                      MPI_COMM_WORLD);}}
        printf ("\nMATRIX B ELEMENTS\n");
        for (i=0;i<DIM;i++) {
             printf ("\n");
             for (j=0;j<DIM;j++) {
                  printf ("%.3f ", bMatrix[i][j]); }}
        printf ("\n"); }
    MPI_Finalize ();
    return (0); }
    
    
    
