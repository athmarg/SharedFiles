#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define N 20
#define true 0
#define false 1

typedef struct Complex {
    double real;
    double imag; } Complex;

void ComplexProduct (Complex * inVec, Complex * inOutVec,
                     int * length, MPI_Datatype * cType) {
    int i; Complex c;
    for (i=0;i<*length;++i) {
         c.real=inOutVec->real*inVec->real-
                inOutVec->imag*inVec->imag;
         c.imag=inOutVec->real*inVec->imag-
                inOutVec->imag*inVec->real;
    *inOutVec = c;
    inVec ++;
    inOutVec ++; }}

int main (int argc, char ** argv) {
    int i, rank;
    Complex a[N],b[N];
    MPI_Op complexProd;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Datatype complexType;
    MPI_Type_contiguous (2, MPI_DOUBLE, &complexType);
    MPI_Type_commit (&complexType);
    for (i=0;i<N;i++) {
         a[i].real=(double)rand()/RAND_MAX;
         a[i].imag=(double)rand()/RAND_MAX;
         b[i].real=(double)rand()/RAND_MAX;
         b[i].imag=(double)rand()/RAND_MAX; }
    MPI_Op_create((MPI_User_function*)ComplexProduct,
                  true, &complexProd);
    MPI_Reduce(a,b,N,complexType,complexProd,0,MPI_COMM_WORLD);
    if (rank==0) {
        for (i=0;i<N;i++)
        printf ("Complex #%03d: Real ->  %.3f Imag -> %.3f\n",
                i, b[i].real, b[i].imag); }
    MPI_Op_free (&complexProd);
    MPI_Type_free (&complexType);
    MPI_Finalize ();
    return (0); }
    
    
    
    
    
    
