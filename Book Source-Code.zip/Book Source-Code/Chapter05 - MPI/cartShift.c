#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main (int argc, char ** argv) {
    MPI_Comm cartComm;
    int counter, rank, size;
    int dims [3] = {5,4,2};
    int periodic [3] = {true, true, true};
    int sourceRank, destRank;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Cart_create (MPI_COMM_WORLD, 3, dims,
        periodic, true, &cartComm);
    for (counter=0;counter<3;counter++) {
          MPI_Cart_shift (cartComm, counter, 1,
                   &sourceRank, &destRank);
          printf ("Proc %02d: Src %02d, \
                   Dest %02d for dim %d\n", 
                   rank,sourceRank, 
                   destRank, counter); }
    MPI_Finalize();
    return (0); }
    
    
    
    
    
    
    
    
    
