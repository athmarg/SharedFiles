#include <stdio.h>
#include <stdlib.h>

#define ROWSA  10  /* rows of matrix A     */
#define COLSA   7  /* columns of matrix A  */
#define ROWSB   7  /* rows of matrix B     */
#define COLSB   5  /* columns of matrix B  */

void main(void) {
     int  i,j,k;
     double aMatrix[ROWSA][COLSA];
     double bMatrix[ROWSB][COLSB];
     double cMatrix[ROWSA][COLSB];

     for (i=0;i<ROWSA;i++)
          for (j=0;j<COLSA;j++)
               aMatrix[i][j]= (double)rand()/RAND_MAX;

     for (i=0;i<ROWSB;i++)
          for (j=0;j<COLSB;j++)
               bMatrix[i][j]= (double)rand()/RAND_MAX;

     for(i=0;i<ROWSA;i++)
         for (j=0;j<COLSB;j++)
              cMatrix[i][j] = 0.0;

     for (i=0;i<ROWSA;i++)
          for (j=0;j<COLSB;j++)
               for (k=0;k<COLSA;k++)
                    cMatrix[i][j]+=aMatrix[i][k]*bMatrix[k][j];

     printf("Values of Matrix A \n");
     for (i=0;i<ROWSA;i++) {
          printf("\n");
          for (j=0;j<COLSA;j++)
               printf("%.3f ", aMatrix[i][j]); }
     printf ("\n\n");

     printf("Values of Matrix B \n");
     for (i=0;i<ROWSB;i++) {
          printf("\n");
          for (j=0;j<COLSB;j++)
               printf("%.3f ", bMatrix[i][j]); }
     printf ("\n\n");
     
     printf("Values of Matrix C \n");
     for (i=0;i<ROWSA;i++) {
          printf("\n");
          for (j=0;j<COLSB;j++)
               printf("%.3f ", cMatrix[i][j]); }
     printf ("\n\n"); }
     
     
     
     
