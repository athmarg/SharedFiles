#include <mpi.h>
#include <stdio.h>

int main (int argc, char * argv[]) {
    int rank, size, retVal;
    MPI_Status status;
    char inMessage, outMessage='x';
    retVal = MPI_Init (&argc,&argv);
    if (retVal!= MPI_SUCCESS) {
        printf ("Error starting MPI program. Terminating.\n");
        MPI_Abort (MPI_COMM_WORLD, retVal);  }
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (rank==0) {
        MPI_Send (&outMessage,1,MPI_CHAR,1,0,MPI_COMM_WORLD);
        MPI_Recv (&inMessage,1,MPI_CHAR, 1,0, MPI_COMM_WORLD,&status);
        printf ("Process %02d send %c and received %c\n", rank, outMessage, inMessage); }
    else if (rank==1) {
        MPI_Recv (&inMessage,1,MPI_CHAR,0,0, MPI_COMM_WORLD,&status);
        MPI_Send (&outMessage,1,MPI_CHAR,0,0, MPI_COMM_WORLD);
        printf ("Process %02d send %c and received %c\n", rank, outMessage, inMessage); }
    MPI_Finalize ();
    return (0); }
    
    
    
