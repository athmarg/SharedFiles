#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ROWSA 10
#define COLSA 12
#define ROWSB 12
#define COLSB 05

#define OUT 1
#define IN  2

int main(int argc,char * argv[]){
    int rank, size;
    int rows, averageRows, extraRows;
    int offset, i, j, k;
    double  aMatrix[ROWSA][COLSA];
    double  bMatrix[ROWSB][COLSB];
    double  cMatrix[ROWSA][COLSB];
    MPI_Status status;

    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    if (size==1) {
        printf ("The program execution requires at least \
                 2 processes. Aborting...\n");
        MPI_Abort(MPI_COMM_WORLD, -1);  }

    // The problem setup is performed by the process R=0
    if (rank==0) {
        // Matrices A and B are initialized to random values
        // in the interval [0,1]
        for (i=0;i<ROWSA;i++)
             for (j=0;j<COLSA;j++)
                  aMatrix[i][j]= (double)rand()/RAND_MAX;
        for (i=0;i<ROWSB; i++)
             for (j=0;j<COLSB;j++)
                  bMatrix[i][j]= (double)rand()/RAND_MAX;

        // The variables averageRows and extraRows are
        // initialized
        averageRows = ROWSA/(size-1);
        extraRows = ROWSA%(size-1);
        offset = 0;
        
        // Data are sent to the target processes
        for (i=1;i<=(size-1);i++) {
             rows=(i<=extraRows)?averageRows+1:averageRows;
             printf("%d rows are sending to process %d\n",rows,i);
             MPI_Send(&offset,1,MPI_INT,i,OUT,MPI_COMM_WORLD);
             MPI_Send(&rows,1,MPI_INT,i,OUT,MPI_COMM_WORLD);
             MPI_Send(&aMatrix[offset][0],rows*COLSA,MPI_DOUBLE,
                      i,OUT, MPI_COMM_WORLD);
             MPI_Send(&bMatrix,COLSA*COLSB,MPI_DOUBLE,i,OUT,
                      MPI_COMM_WORLD);
             offset = offset + rows; }

        // The values of the matrix C cells are received from
        // the target processes
        for (i=1;i<=(size-1);i++) {
             MPI_Recv(&offset,1,MPI_INT,i,IN,
                 MPI_COMM_WORLD,&status);
             MPI_Recv(&rows,1,MPI_INT,i,IN,
                 MPI_COMM_WORLD,&status);
             MPI_Recv(&cMatrix[offset][0],rows*COLSB,
                 MPI_DOUBLE,i,IN,MPI_COMM_WORLD,&status); }

        // The contents of the matrix product C
        // are printed in the screen
        printf("\nValues of matrix C\n");
        for (i=0;i<ROWSA;i++) {
             printf("\n");
             for (j=0;j<COLSB;j++)
                  printf("%6.2f   ", cMatrix[i][j]); }
             printf ("\n"); }

    // The next code segment is executed by the remaining
    // process, i.e. with a rank value different than zero
    else {
       // Data are received from the process R=0
       MPI_Recv(&offset,1,MPI_INT,0,OUT,MPI_COMM_WORLD,&status);
       MPI_Recv(&rows,1,MPI_INT,0,OUT,MPI_COMM_WORLD,&status);
       MPI_Recv(&aMatrix,rows*COLSA,MPI_DOUBLE,0,OUT,
                MPI_COMM_WORLD,&status);
       MPI_Recv(&bMatrix,COLSA*COLSB,MPI_DOUBLE,0,OUT,
                MPI_COMM_WORLD,&status);

       // The matrix product C=A*B is estimated
       for (k=0; k<COLSB; k++)
            for (i=0; i<rows; i++) {
                 cMatrix[i][k] = 0.0;
                 for (j=0; j<COLSA; j++)
                      cMatrix[i][k]+=
                          aMatrix[i][j]*bMatrix[j][k]; }
       // The calculation results are sent to the process R=0
       MPI_Send(&offset, 1, MPI_INT, 0, IN, MPI_COMM_WORLD);
       MPI_Send(&rows, 1, MPI_INT, 0, IN, MPI_COMM_WORLD);
       MPI_Send(&cMatrix,rows*COLSB,MPI_DOUBLE,0,
                IN, MPI_COMM_WORLD); }
    MPI_Finalize();
    return (0); }
    
    
    
    
