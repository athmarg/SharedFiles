/* Source File CPS.cpp */

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LPC_ORDER 8

void cpsCoding (double * lpcVector,double * cpsVector) {
    int counter,index; double sum; cpsVector[0]=0;
    for (counter=1;counter<=LPC_ORDER;++counter) {
         sum=0.0;
         for (index=1;index<counter;++index)
              sum += (double)index*cpsVector[index-1]*
                   lpcVector[counter-index]/
                             (double)counter;
         cpsVector[counter-1]=lpcVector[counter]+sum; }}

int main(int argc, char* argv[]) {
    int rank, size, samples;
    int counter, index, frames;
    MPI_Comm interComm;
    double lpcCoefficients [LPC_ORDER+1];
    double cpsCoefficients [LPC_ORDER+1];
    double * currentFrame;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Comm_get_parent (&interComm);
    if (interComm==MPI_COMM_NULL) {
        if (rank==0)
            printf ("Parent Comm does not exist.\n");
        MPI_Finalize ();
        return (-1); }
    MPI_Bcast (&frames, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&samples, 1, MPI_INT, 0, MPI_COMM_WORLD);
    currentFrame = (double *) malloc (samples*sizeof(double));
    for (counter=0;counter<frames;counter++) {
         MPI_Bcast (currentFrame, samples, MPI_DOUBLE, 
                    0, MPI_COMM_WORLD);
         MPI_Bcast (lpcCoefficients, LPC_ORDER+1, MPI_DOUBLE, 
                    0, MPI_COMM_WORLD);
         cpsCoding (lpcCoefficients, cpsCoefficients);
         printf ("Fr%02d CPS > ", counter);
         for (index=1;index<LPC_ORDER;index++)
              printf ("%+.3f ", cpsCoefficients[index]);
         printf ("\n"); }
    free (currentFrame);
    MPI_Finalize();
    return 0; }
