#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LENGTH 100

int main (int argc, char ** argv) {
    int counter, rank, size;
    int buffer [LENGTH];
    char fileName [64] = "data.txt";
    MPI_File fileHandle;
    int disp=0, count, offset;
    MPI_Datatype eType = MPI_INT;
    MPI_Datatype fType = MPI_INT;
    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    offset = rank*LENGTH;
    for (counter=0;counter<LENGTH;counter++)
         buffer [counter] = counter*(rank+1);
    MPI_File_open (MPI_COMM_WORLD, fileName, MPI_MODE_RDWR | MPI_MODE_CREATE, MPI_INFO_NULL, &fileHandle);
    MPI_File_set_view (fileHandle, disp, eType, fType, "native", MPI_INFO_NULL); 
    MPI_File_write_at (fileHandle, offset, buffer, 100, MPI_INT, &status);
    MPI_Get_elements (&status, MPI_INT, &count);
    printf ("%d elements saved to disk from proc %d (offset is %d)\n", count, rank, offset);
    MPI_File_close (&fileHandle);
    MPI_Finalize();
    return (0); }
    
    
    
    
    
