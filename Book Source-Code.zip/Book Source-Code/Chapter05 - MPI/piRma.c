#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char ** argv) {
    int intervals=1000000, counter, rank, size;
    MPI_Win intervalWin, piWin;
    double piValue, h, sum, xVal, localPiValue;
    double startTime, endTime;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (rank==0) {
        MPI_Win_create (&intervals, sizeof(int), 1,
            MPI_INFO_NULL,MPI_COMM_WORLD, &intervalWin);
        MPI_Win_create (&piValue, sizeof(double), 1,
            MPI_INFO_NULL,MPI_COMM_WORLD, &piWin); }
    else {
        MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
                        MPI_COMM_WORLD, &intervalWin);
        MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
                        MPI_COMM_WORLD, &piWin); }
    startTime = MPI_Wtime();
    if (rank==0) {
        intervals = 1000000;
        piValue = 0.0;  }
    if (intervals==0) return (-1);
    MPI_Win_fence (0, intervalWin);
    if (rank)
        MPI_Get (&intervals, 1, MPI_INT, 0, 0, 1,
            MPI_INT, intervalWin);
        MPI_Win_fence (0, intervalWin);
    h=1.0/(double)intervals;
    sum = 0.0;
    for (counter=rank+1;counter<=intervals;
         counter+=size) {
         xVal = h*((double)counter-0.5);
         sum += (4.0/(1.0+xVal*xVal)); }
    localPiValue = h * sum;
    printf ("Process %02d found a local sum of %.6f\n",
             rank, localPiValue);
    MPI_Win_fence (0, piWin);
    MPI_Accumulate (&localPiValue, 1, MPI_DOUBLE, 0, 0, 1,
                    MPI_DOUBLE, MPI_SUM, piWin);
    MPI_Win_fence (0, piWin);
    endTime = MPI_Wtime();
    if (rank==0)
         printf ("%d Intervals, Pi: %.6f Time: %.6f\n", 
                  intervals, piValue, endTime-startTime);
    MPI_Win_free (&intervalWin);
    MPI_Win_free (&piWin);
    MPI_Finalize();
    return (0); }
    
    
    
    
