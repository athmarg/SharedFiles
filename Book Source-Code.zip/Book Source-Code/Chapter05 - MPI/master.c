/* Source File Master.c */

#include <mpi.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define maxProcs 5
#define cells 10

int main(int argc, char* argv[]) {
    int rank, size, counter, index;
    MPI_Comm interComm;
    double matrix [maxProcs][cells];
    int rows = maxProcs, columns = cells;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    for (counter=0;counter<rows;counter++)
         for (index=0;index<columns;index++)
              matrix[counter][index]=
                    (double)rand()/RAND_MAX;
    printf ("Master process data\n");
    for (counter=0;counter<rows;counter++) {
         for (index=0;index<columns;index++)
              printf ("%.3f ", matrix[counter][index]);
         printf ("\n"); }
    printf ("Spawning %d slaves ...\n", maxProcs);
    MPI_Comm_spawn ("./slave", MPI_ARGV_NULL, 
             maxProcs, MPI_INFO_NULL, 0, MPI_COMM_WORLD,
             &interComm, MPI_ERRCODES_IGNORE);
    MPI_Send (&rows, 1, MPI_DOUBLE, 0, 0, interComm);
    MPI_Send (&columns, 1, MPI_DOUBLE, 0, 0, interComm);
    MPI_Send (&matrix, maxProcs*columns, MPI_DOUBLE,
              0, 0, interComm);
    MPI_Finalize();
    return 0; }
    
    
    
    
    
    
