// Source File FFT.cpp

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr
#define PI       (4.0)*atan(1.0)
#define PRINT     6

int bit_swap (int i, int nu) {
    int ib=0, i1,i2;
    for(i1=0;i1!=nu;i1++) {
         i2=i/2;
         ib=ib*2+i-2*i2;
         i=i2;}
    return(ib); }
    
void swap(double x1, double x2)  {
    double temp_x;
    temp_x=x1; x1=x2;
    x2=temp_x; }

void fft (double * real_data, double * imag_data,
          int n_pts, int nu, int inv) {
    int n2,j,l,i,ib,k,k1,k2,sgn;
    double tr,ti,arg,nu1,c,s;
    n2=n_pts/2;
    nu1=nu-1.0;
    k=0;
    sgn=inv?-1:1;
    for (l=0;l!=nu;l++) {
      do {
          for (i=0;i!=n2;i++) {
             j=(int)(k/(pow(2.0,nu1)));
             ib=bit_swap(j,nu);
             arg=2.0*PI*ib/n_pts;
             c=cos(arg);
             s=sgn*sin(arg);
             k1=k;
             k2=k1+n2;
             tr=*(real_data+k2)*c+*(imag_data+k2)*s;
             ti=*(imag_data+k2)*c-*(real_data+k2)*s;
             *(real_data+k2)=*(real_data+k1)-tr;
             *(imag_data+k2)=*(imag_data+k1)-ti;
             *(real_data+k1)=*(real_data+k1)+tr;
             *(imag_data+k1)=*(imag_data+k1)+ti;
             k++; }
          k+= n2;
          } while (k<n_pts-1);
      k=0; nu1-=1.0; n2/=2; }
    for (k=0;k!=n_pts;k++) {
         ib=bit_swap(k,nu);
         if (ib>k) {
         swap(*(real_data+k),*(real_data+ib));
         swap(*(imag_data+k),*(imag_data+ib));}}
    if (inv)
        for (k=0;k!=n_pts;k++) {
             *(real_data+k)/=n_pts;
             *(imag_data+k)/=n_pts; }}
             
int main(int argc, char * argv[]) {
    int rank, size, samples;
    int counter, index, frames, logS;
    MPI_Comm interComm;
    double * currentFrame, * imag;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);

    MPI_Comm_get_parent (&interComm);

    if (interComm==MPI_COMM_NULL) {
        if (rank==0)
            printf ("Parent Communicator does not exists...\n");
        MPI_Finalize ();
        return (-1); }
    MPI_Bcast (&frames, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&samples, 1, MPI_INT, 0, MPI_COMM_WORLD);

    logS = (int)(log10(samples)/log10(2.0));
    currentFrame = (double *) malloc (samples*sizeof(double));
    imag = (double *) malloc (samples*sizeof(double));

   for (counter=0;counter<frames;counter++) {
         MPI_Bcast (currentFrame, samples, MPI_DOUBLE, 0,
                    MPI_COMM_WORLD);
         for (index=0;index<samples;index++) imag [index] = 0.0;
         fft (currentFrame, imag, samples, logS, +1);

         printf ("Fr%02d FFT (REAL [0-->%d]) > ",
                 counter, PRINT);
         for (index=0;index<PRINT;index++)
              printf ("%+.3f ", currentFrame[index]);
         printf ("\n");
         printf ("Fr%02d FFT (IMAG [0-->%d]) > ",
                 counter, PRINT);
         for (index=0;index<PRINT;index++)
              printf ("%+.3f ", imag[index]);
         printf ("\n"); }

    free (currentFrame);
    free (imag);
    MPI_Finalize();
    return 0; }

