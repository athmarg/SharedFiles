#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define true 0
#define false 1

double ** Allocate2DMatrix (int rows, int columns) {
    int counter; double ** matrix;
    matrix = (double **) malloc (rows*sizeof(double*));
    if (!matrix) return (NULL);
    for (counter=0;counter<rows;counter++) {
    matrix[counter]=
          (double *)malloc(columns*sizeof(double));
    if (!matrix[counter]) return (NULL);}
    return matrix; }

void Free2DMatrix (double ** matrix, int rows) {
    int counter;
    for (counter=0;counter<rows;counter++)
         free ((double *)matrix[counter]);
    free ((double **)matrix);}

double Distance (double * x, double * y, int N) {
    int counter; double dist = 0.0;
    for (counter=0;counter<N;counter++)
         dist += pow((x[counter]-y[counter]),2);
    return (sqrt(dist)); }

int Jacobi (double ** a, double * x, double * b, int N,
            double tol, int epochs, int * flag) {
    int counter, index, cycles;
    double * oldX;
    oldX = (double *) malloc (N*sizeof(double));
    if (!oldX) return (-1);
    for (counter=0;counter<N;counter++)
         x[counter]=b[counter];
    cycles=0;
    do {
         cycles++;
         for (counter=0;counter<N;counter++)
              oldX[counter]=x[counter];
         for (counter=0;counter<N;counter++) {
              x[counter]=b[counter];
              for (index=0;index<N;index++) {
                   if (counter!=index)
                       x[counter]-=
                         a[counter][index]*oldX[index]; }
              x[counter]/=a[counter][counter]; }
       } while ((cycles<epochs)&&
                (Distance(x,oldX, N)>tol));
    if (Distance(x,oldX, N)<tol) (*flag)=true;
    else (*flag)=false;
    free (oldX);
    return (0); }

int main (int argc, char ** argv) {
    int rank, size; double ** matrix;
    double bCol[4]={7,-1,-5,2};
    double x[4], tol=0.0000001;
    int counter, M=10000; int flag;
    matrix = Allocate2DMatrix (4,4);
    matrix[0][0]=10; matrix[0][1]=1;
    matrix[0][2]=1; matrix[0][3]=1;
    matrix[1][0]=3; matrix[1][1]=5;
    matrix[1][2]=0; matrix[1][3]=-1;
    matrix[2][0]=2; matrix[2][1]=-1;
    matrix[2][2]=10; matrix[2][3]=-2;
    matrix[3][0]=0; matrix[3][1]=3;
    matrix[3][2]=0; matrix[3][3]=-5;
    Jacobi (matrix,x,bCol,4,tol,M,&flag);
    if (flag==true) {
        printf ("System solution is : ");
        for (counter=0;counter<4;counter++)
             printf ("%.3f ", x[counter]);
        printf ("\n"); }
    else 
        printf ("No solution available\n");
    Free2DMatrix (matrix, 4);
    return (0); }    
    
    
    
    
    
    
    
    
