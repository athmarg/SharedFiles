#include <mpi.h>
#include <math.h>
#include <stdio.h>

double func (double x) { return (3*pow(x,2)+1); }

double CalcIntegral (double a, double b, 
                     int N, double base) {
    double x, integral; int i;
    integral = (func(a)+func(b))/2.0;
    x = a;
    for (i=1;i<N-1;i++) {
         x = x+base;
         integral = integral + func(x); }
         integral = integral * base; 
         return (integral); }

int main (int argc, char* argv[]) {
    int rank, size, localN;
    int sourceRank, destinationRank, messageTag=0;
    double a=1.0, b=4.0;
    unsigned long N = 1000;
    double localA, localB, base = (b-a)/N;
    double localIntegral=0.0, totalIntegral=0.0;

    MPI_Status status;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    localN = N/size;
    localA=a+rank*localN*base;
    localB=localA+localN*base;
    localIntegral = CalcIntegral (localA, localB, localN, base);
    printf("Process %d: a=%.6f b=%.6f integral=%.6f\n",
            rank, localA, localB, localIntegral);
    if (rank==0) {
        totalIntegral = localIntegral;
        for (sourceRank=1;sourceRank<size;sourceRank++) {
             MPI_Recv (&localIntegral,1,MPI_DOUBLE, sourceRank,
                       messageTag, MPI_COMM_WORLD, &status);
        totalIntegral += localIntegral; }}
    else {
        destinationRank=0;
        MPI_Send (&localIntegral,1,MPI_DOUBLE,destinationRank,
                  messageTag, MPI_COMM_WORLD); }
    if (rank==0) {
        printf ("%ld trapezoids used ==> integral is %.6f\n", 
                 N, totalIntegral); }
    MPI_Finalize();
    return 0; }
    
    
    
    
    
    
