#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ROWSA 10
#define COLSA 12
#define ROWSB 12
#define COLSB 05

int main(int argc,char * argv[]){
    int i, j, k, rank, size, rows, bufSize;
    double aMatrix[ROWSA][COLSA];
    double bMatrix[ROWSB][COLSB];
    double cMatrix[ROWSA][COLSB];
    double *inBuffer, *outBuffer;
    double *result;
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    if (ROWSA%size) {
        if (rank==0)
            printf ("Invalid row number.\n");
            MPI_Finalize();
            return (-1); }
    rows = ROWSA/size;
    bufSize = rows*COLSA*sizeof(double);
    inBuffer = (double *) malloc (bufSize);
    if (!inBuffer) {
        if (rank==0)
            printf ("Not enough memory.\n");
            MPI_Finalize();
            return (-2); }
    outBuffer = (double *) malloc (bufSize);
    if (!outBuffer) {
        if (rank==0)
            printf ("Not enough memory.\n");
            MPI_Finalize();
            return (-3); }
    result = (double *) malloc (size*bufSize);
    if (!result) {
        if (rank==0)
            printf ("Not enough memory.\n");
            MPI_Finalize();
            return (-4); }
    if (rank==0) {
        for (i=0;i<ROWSA;i++)
             for (j=0;j<COLSA;j++)
                  aMatrix[i][j]=
                         (double)rand()/RAND_MAX;
    for (i=0;i<ROWSB; i++)
         for (j=0;j<COLSB;j++)
              bMatrix[i][j]=
                         (double)rand()/RAND_MAX; }
    MPI_Bcast (&rows,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast (&bMatrix,COLSA*COLSB,
               MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Scatter (&aMatrix,rows*COLSA,MPI_DOUBLE,
                 inBuffer, rows*COLSA, MPI_DOUBLE, 0, 
                 MPI_COMM_WORLD);
    for (i=0;i<rows;i++) {
         for (j=0;j<COLSA;j++) {
              outBuffer[i*COLSA+j]=0.0;
              for (k=0;k<COLSA;k++)
                   outBuffer[i*COLSA+j] +=
                            inBuffer[i*COLSA+k]*
                              bMatrix[k][j]; }}
    MPI_Gather (outBuffer,rows*COLSA, MPI_DOUBLE,
                result, rows*COLSA, MPI_DOUBLE, 0, 
                MPI_COMM_WORLD);
    for (i=0;i<ROWSA;i++) {
         for (j=0;j<COLSB;j++)
              cMatrix[i][j]=result[i*COLSA+j]; }
    if (rank==0) {
        printf("\nValues of matrix C\n");
    for (i=0;i<ROWSA;i++) {
         printf("\n");
    for (j=0;j<COLSB;j++)
         printf("%.6f ", cMatrix[i][j]); }
    printf ("\n"); }
    free ((double *)inBuffer);
    free ((double *)outBuffer);
    free ((double *)result);
    MPI_Finalize();
    return (0); }
