#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ROWS  10
#define COLS   8
#define sRows  3
#define sCols  6

int main (int argc, char ** argv) {
    int i, j, rank, size, x=2, y=2;
    double aMatrix[ROWS][COLS];
    double bMatrix[ROWS][COLS];
    MPI_Datatype matType;
    MPI_Status status;

    if ((sRows>=ROWS)||(sCols>=COLS)) {
        if (rank==0)
            printf ("Invalid matrix parameters. Aborting...\n");
        MPI_Abort(MPI_COMM_WORLD,-1); }

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);

    if (size!=2) {
        if (rank==0)
            printf ("Invalid process number. Aborting...\n");
        MPI_Abort(MPI_COMM_WORLD,-2); }

    MPI_Type_vector (sRows,sCols,COLS,MPI_DOUBLE,&matType);
    MPI_Type_commit (&matType);
    for (i=0;i<ROWS;i++) {
         for (j=0;j<COLS;j++) {
              aMatrix[i][j]=(double)rand()/RAND_MAX;
              bMatrix[i][j]=0.0; }}

    if (rank==0) {
        printf ("MATRIX A ELEMENTS\n");
        for (i=0;i<ROWS;i++) {
               printf ("\n");
               for (j=0;j<COLS;j++) {
             printf ("%.3f ", aMatrix[i][j]); }}
        printf("\n");

        printf ("\nMATRIX B ELEMENTS BEFORE SEND\n");
        for (i=0;i<ROWS;i++) {
             printf ("\n");
             for (j=0;j<COLS;j++) {
                  printf ("%.3f ", bMatrix[i][j]); }}
         printf("\n");         

        MPI_Send(&aMatrix[x][y],1,matType,1,0,MPI_COMM_WORLD);}
    else {
        MPI_Recv (&bMatrix[x][y],1,matType,0,0,
                  MPI_COMM_WORLD,&status);
        printf ("\nMATRIX B ELEMENTS AFTER SEND\n");
        for (i=0;i<ROWS;i++) {
             printf ("\n");
             for (j=0;j<COLS;j++) {
                  printf ("%.3f ", bMatrix[i][j]); }}
         printf("\n"); }

    MPI_Type_free (&matType);
    MPI_Finalize ();
    return (0); }
    
    
    
    
    
    
    
