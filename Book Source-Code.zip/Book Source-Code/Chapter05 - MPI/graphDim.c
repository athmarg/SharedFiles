#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

int main (int argc, char ** argv) {
   int i, oldRank, newRank;
   MPI_Comm graphComm;
   int neighborNumber, * neighbors;
   int nodeNumber = 5;
   int index[5] = {3, 4, 6, 8, 10};
   int edges[10] = {2,3, 4, 3, 0, 4, 0, 1, 0, 2};
   MPI_Init (&argc, &argv);
   MPI_Comm_rank (MPI_COMM_WORLD, &oldRank);
   MPI_Graph_create (MPI_COMM_WORLD, 5, index,
             edges, true, &graphComm);
   MPI_Comm_rank (graphComm, &newRank);
   printf ("Proc %d (MPI_COMM_WORLD) is %d (graphComm)\n", 
            oldRank, newRank);
   MPI_Graph_neighbors_count (graphComm, newRank,
            &neighborNumber);
   neighbors = (int *) malloc (neighborNumber*sizeof(int));
   MPI_Graph_neighbors (graphComm, newRank,
             neighborNumber, neighbors);
   printf ("Process %d has %d neighbors: ", 
            newRank, neighborNumber);
   for (i=0;i<neighborNumber;i++)
        printf("%d ", neighbors[i]);
   printf ("\n");
   free ((int *)neighbors);
   MPI_Finalize ();
   return (0); }
   
