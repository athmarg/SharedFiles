#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>


int main (int argc, char ** argv) {
    int i, size; long int extent;
    int mpiTypes[12]={MPI_CHAR,MPI_SHORT,
           MPI_INT,MPI_LONG,
           MPI_UNSIGNED_CHAR,MPI_UNSIGNED_SHORT, 
           MPI_UNSIGNED,MPI_UNSIGNED_LONG,
           MPI_FLOAT,MPI_DOUBLE,MPI_LONG_DOUBLE,
           MPI_BYTE};
    char mpiNames[12][32]={"MPI_CHAR", "MPI_SHORT", 
           "MPI_INT", "MPI_LONG","MPI_UNSIGNED_CHAR",
           "MPI_UNSIGNED_SHORT", "MPI_UNSIGNED",
           "MPI_UNSIGNED_LONG", "MPI_FLOAT", 
           "MPI_DOUBLE", "MPI_LONG_DOUBLE", 
           "MPI_BYTE"};
    MPI_Init (&argc, &argv);
    for (i=0;i<12;i++) {
         MPI_Type_size (mpiTypes[i], &size);
         MPI_Type_extent (mpiTypes[i], &extent);
         printf ("%s\t==>\tSize=%d\tExtent=%ld\n", 
                  mpiNames[i], size, extent); }
         MPI_Finalize();
         return (0); }
         
         
         
         
         
         
         
