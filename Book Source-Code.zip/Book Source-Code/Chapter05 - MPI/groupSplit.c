#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 4

int main (int argc, char ** argv) {
    int i, oldRank, oldSize, a = 10; double buf; 
    double b [DIM] = {0.125, 0.450, 1.375, 2.225};
    int ranks1[DIM], ranks2[DIM]; char str[256]; 
    MPI_Group commGroup, newGroup1, newGroup2;
    int newRank1=0, newRank2=0; int err;
    MPI_Comm newComm1 = 0, newComm2 = 0;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &oldRank);
    MPI_Comm_size (MPI_COMM_WORLD, &oldSize);
    if (oldSize!=2*DIM) {
        if (oldRank==0)
            printf ("Invalid process number\n");
        MPI_Finalize ();
        return (-1); }
    for (i=0;i<DIM;i++) {
         ranks1[i] = 2*i;
         ranks2[i] = 2*i+1; }
    MPI_Comm_group (MPI_COMM_WORLD, &commGroup);
    MPI_Group_incl (commGroup, DIM, ranks1, &newGroup1);
    MPI_Group_incl (commGroup, DIM, ranks2, &newGroup2);
    MPI_Comm_create (MPI_COMM_WORLD, newGroup1, &newComm1);
    MPI_Comm_create (MPI_COMM_WORLD, newGroup2, &newComm2);
    if (newComm1!=MPI_COMM_NULL) 
        MPI_Comm_rank (newComm1, &newRank1);
    if (newComm2!=MPI_COMM_NULL) 
        MPI_Comm_rank (newComm2, &newRank2);
    if (newComm1!=MPI_COMM_NULL) {
        MPI_Bcast (&a, 1, MPI_INT, 0, newComm1);
        printf ("Proc %d of newGroup1 received a value of %d from proc 0\n", 
                 newRank1, a); }
    if (newComm2!=MPI_COMM_NULL) {
        MPI_Scatter (&b, 1, MPI_DOUBLE, &buf, 1, MPI_DOUBLE, 2, newComm2);
        printf ("Proc %d of newGroup2 received a value of %f from process 2\n", 
                 newRank2, buf); }
    MPI_Group_free (&newGroup1);
    if (newComm1!=MPI_COMM_NULL) 
        MPI_Comm_free (&newComm1);
    MPI_Group_free (&newGroup2);
    if (newComm2!=MPI_COMM_NULL) 
        MPI_Comm_free (&newComm2);
    MPI_Finalize ();
    return (0); }
    
    



    
