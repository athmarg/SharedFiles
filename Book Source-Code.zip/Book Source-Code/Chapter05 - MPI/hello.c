   #include <mpi.h>
   #include <stdio.h>
   
   int main (int argc, char * argv[]) {
    char message [16] = "Hello World !!";
    MPI_Init (&argc, &argv);
    printf ("\%s\n", message);
    MPI_Finalize();
    return (0);}
