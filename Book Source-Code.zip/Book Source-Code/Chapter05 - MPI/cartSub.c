#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main (int argc, char ** argv) {
    MPI_Comm cartComm, newComm;
    int rank, size, newDim, newRank;
    int dims [3] = {5,4,3};
    int periodic [3] = {false, true, false};
    int remainDims [3]= {true, false, true};
    int * newCoords, * newDims;
    MPI_Init (&argc, &argv);
    
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    
    MPI_Cart_create (MPI_COMM_WORLD, 3, dims,
             periodic, true, &cartComm);
    MPI_Cart_sub (cartComm, remainDims, &newComm);
    MPI_Cartdim_get (newComm, &newDim);
    newCoords = (int *)malloc(newDim*sizeof(int));
    newDims = (int *)malloc(newDim*sizeof(int));
    
    MPI_Cart_get (newComm, newDim, newDims, 
                  periodic, newCoords);
    MPI_Comm_rank (newComm, &newRank);
    printf ("Proc %02d (MPI_COMM_WORLD) ==> \
             %02d (newComm)\n", rank, newRank);
    free (newCoords);
    free (newDims);
    MPI_Comm_free (&newComm);
    MPI_Finalize();
    return (0); }
    
    
    
    
    
    
    
