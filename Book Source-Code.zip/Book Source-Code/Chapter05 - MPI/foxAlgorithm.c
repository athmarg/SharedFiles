/* book pages 336-342 */
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

#define ORDER 12

typedef struct GridInfo {
   int processNumber;  // total number of processes
   MPI_Comm gridComm;  // communicator for entire grid
   MPI_Comm rowComm;   // communicator for current row
   MPI_Comm colComm;   // communicator for current column
   int gridOrder;      // the order of grid
   int currentRow;     // row of current process
   int currentCol;     // column of current process
   int gridCommRank;   // rank of current process in gridComm
   } GridInfo;

void PrintGridInfo (GridInfo * grid) {
   printf ("Number of Processes is %d\n", grid->processNumber);
   printf ("Grid Comm Identifier is %d\n", grid->gridComm);
   printf ("Row Comm Identifier is %d\n", grid->rowComm);
   printf ("Column Comm Identifier is %d\n", grid->colComm);
   printf ("Grid Order is %d\n", grid->gridOrder);
   printf ("Current Process Coordinates are (%d, %d)\n",
           grid->currentRow, grid->currentCol);
   printf ("Process rank in Grid is %d\n",
           grid->gridCommRank); }

double ** Allocate2DMatrix (int rows, int columns) {
   int counter; double ** matrix;
   matrix = (double **) malloc (rows*sizeof(double *));
   if (!matrix) return (NULL);
   for (counter=0;counter<rows;counter++) {
        matrix[counter] =
              (double *) malloc (columns*sizeof(double));
        if (!matrix[counter]) return (NULL);}
   return matrix; }

void Free2DMatrix (double ** matrix, int rows) {
   int counter;
   for (counter=0;counter<rows;counter++)
        free ((double *)matrix[counter]);
   free ((double **)matrix);}

int SetupGrid (GridInfo * grid) {
   int flag, worldRank;
   // cartesian topology is 2D
   int dims[2], periods[2], gridCoords[2], subCoords[2];
   // if MPI has not been initialized, abort procedure
   MPI_Initialized(&flag);
   if (flag==false) return (-1);
   MPI_Comm_rank (MPI_COMM_WORLD, &worldRank);
   MPI_Comm_size (MPI_COMM_WORLD, &(grid->processNumber));

   // check if process number is a perfect square
   if (sqrt((double)grid->processNumber)==
            (int)sqrt((double)grid->processNumber))
       grid->gridOrder=(int)sqrt((double)grid->processNumber);
   else return (-2);
   dims[0]=dims[1]=grid->gridOrder;
   // a circular shift is required for the second dimension
   periods[0]=periods[1]=true;
   // create communicator for the process grid
   MPI_Cart_create (MPI_COMM_WORLD, 2, dims, periods,
                    true, &(grid->gridComm));
   // retrieve the process rank in the grid Communicator
   // and the process coordinates in the cartesian topology
   MPI_Comm_rank (grid->gridComm, &(grid->gridCommRank));
   MPI_Cart_coords (grid->gridComm,
            grid->gridCommRank, 2, gridCoords);
   grid->currentRow=gridCoords[0];
   grid->currentCol=gridCoords[1];

   // setup row communicators
   subCoords[0]=0; subCoords[1]=1;
   MPI_Cart_sub (grid->gridComm, subCoords, &(grid->rowComm));

   // setup column communicators
   subCoords[0]=1; subCoords[1]=0;
   MPI_Cart_sub (grid->gridComm, subCoords, &(grid->colComm));
   return (0); }

void LocalMatrixProduct (double ** A, double ** B,
     double ** C, int dim) {
   int i,j,k; for (i=0;i<dim;i++) {
   for (j=0;j<dim;j++) {
        for (k=0;k<dim;k++) {
             C[i][j]+=A[i][k]*B[k][j];}}}}

int Scatter2DMatrix (double ** matrix, int N, double ** local,
           int dim, int root, GridInfo * grid) {
   int flag, rank, loops = N/dim; int size, dest, packPosition;
   int counter, index, coords[2], i, j;
   double * tempArray;
   MPI_Status status;
   MPI_Initialized (&flag);
   if (flag==false) return (-1);
   MPI_Comm_rank (MPI_COMM_WORLD, &rank);
   MPI_Comm_size (MPI_COMM_WORLD, &size);

   if ((root<0)||(root>=size)) return (-1);

   tempArray = (double *) malloc (dim*dim*sizeof(double));
   if (!tempArray) return (-1);

   if (rank==root) {
       for (counter=0;counter<loops;counter++) {
          coords[0]=counter;
          for (index=0;index<loops;index++) {
            coords[1]=index;
            MPI_Cart_rank (grid->gridComm, coords, &dest);
            packPosition = 0;
            for (i=dim*counter;i<dim*(counter+1);i++)
                 for (j=dim*index;j<dim*(index+1);j++)
                      MPI_Pack (&matrix[i][j], 1, MPI_DOUBLE,
                          tempArray, 256, &packPosition,
                          MPI_COMM_WORLD);
            if (dest!=root)
                MPI_Send (tempArray, dim*dim, MPI_DOUBLE, dest,
                          0, MPI_COMM_WORLD);
            else {
                for (i=0;i<dim;i++)
                  for (j=0;j<dim;j++)
                     local[i][j]=tempArray[i*dim+j]; }}}}
   else {
       MPI_Recv (tempArray, dim*dim, MPI_DOUBLE, root,
                 0, MPI_COMM_WORLD, &status);
       for (counter=0;counter<dim;counter++)
            for (index=0;index<dim;index++)
                 local[counter][index]=
                       tempArray[counter*dim+index]; }
   free (tempArray);
   return (0); }

int Gather2DMatrix (double ** matrix, int N, double ** local,
          int dim, int root, GridInfo * grid) {
   int flag, rank, loops = N/dim;
   int size, cnt, source, rootCoords[2];
   int counter, index, coords[2], i, j;
   double * tempArray;
   MPI_Status status;
   MPI_Initialized (&flag);
   if (flag==false) return (-1);

   MPI_Comm_rank (MPI_COMM_WORLD, &rank);
   MPI_Comm_size (MPI_COMM_WORLD, &size);

   if ((root<0)||(root>=size)) return (-1);

   tempArray = (double *) malloc (dim*dim*sizeof(double));
   if (!tempArray) return (-1);
   if (rank==root) {
     for (counter=0;counter<loops;counter++) {
        coords[0]=counter;
        for (index=0;index<loops;index++) {
             coords[1]=index;
             MPI_Cart_rank (grid->gridComm, coords, &source);
             if (source==root) {
               MPI_Cart_coords (grid->gridComm,
                                rank, 2,rootCoords);
               for(i=dim*rootCoords[0];
                   i<dim*(rootCoords[0]+1);i++){
                   for(j=dim*rootCoords[1];
                       j<dim*(rootCoords[1]+1);j++){
                              matrix[i][j]=local[i][j]; }}}
             else {
               MPI_Recv (tempArray, dim*dim, MPI_DOUBLE, source,
                         0, MPI_COMM_WORLD, &status);
               cnt=0;
               for (i=dim*counter;i<dim*(counter+1);i++) {
                 for (j=dim*index;j<dim*(index+1);j++) {
                      matrix[i][j]=tempArray[cnt];
                      cnt++; }}}}}}
   else {
     cnt=0;
     for (i=0;i<dim;i++)
       for (j=0;j<dim;j++) {
         tempArray[cnt]=local[i][j];
         cnt++; }

     MPI_Send (tempArray, dim*dim, MPI_DOUBLE, root,
                0, MPI_COMM_WORLD); }
   free (tempArray);
   return (0); }
int Fox (int matrixOrder, GridInfo * grid, double ** localA,
         double ** localB, double ** localC) {

   int i,sourceRank, x,y, destRank, root, cnt;
   int dim=matrixOrder/grid->gridOrder;
   double ** tempMatrix, * sendVec, * recvVec;;
   MPI_Status status;
   MPI_Cart_shift (grid->colComm,0,1,&destRank,&sourceRank);
   tempMatrix=Allocate2DMatrix(dim,dim);
   sendVec = (double *) malloc (dim*dim*sizeof(double));
   recvVec = (double *) malloc (dim*dim*sizeof(double));

   for (x=0;x<dim;x++)
        for (y=0;y<dim;y++) localC[x][y]=0.0;
   for (i=0;i<grid->gridOrder;i++) {
        root=(grid->currentRow+i)%grid->gridOrder;
        if (root==grid->currentCol) {
            cnt=0;
            for (x=0;x<dim;x++) {
                 for (y=0;y<dim;y++) {
                      sendVec[cnt]=localA[x][y];
                      cnt++; }}
            MPI_Bcast (sendVec, dim*dim, MPI_DOUBLE,
                       root, grid->rowComm);
            LocalMatrixProduct (localA,localB,localC,dim); }
        else {
             MPI_Bcast (recvVec, dim*dim, MPI_DOUBLE,
                        root, grid->rowComm);
             for (x=0;x<dim;x++)
                  for (y=0;y<dim;y++)
                       tempMatrix[x][y]=recvVec[x*dim+y];
             LocalMatrixProduct (tempMatrix, localB,
                                 localC, dim); }
        cnt=0;
        for (x=0;x<dim;x++)
             for (y=0;y<dim;y++) {
                  sendVec[cnt]=localB[x][y];
                  cnt++; }

        MPI_Sendrecv_replace (sendVec, dim*dim, MPI_DOUBLE,
            destRank, 0, sourceRank, 0, grid->colComm, &status);

        for (x=0;x<dim;x++)
             for (y=0;y<dim;y++)
                  localB[x][y]=sendVec[x*dim+y]; }

   Free2DMatrix (tempMatrix, dim);
   free (sendVec);
   free (recvVec);
   return (0); }

int main (int argc, char ** argv) {
   int i,j,rank, dim, root=0;
   GridInfo grid;
   double ** localA, ** localB, ** localC;
   double ** aMatrix, ** bMatrix, ** cMatrix;

   MPI_Init (&argc, &argv);
   MPI_Comm_rank (MPI_COMM_WORLD, &rank);

   SetupGrid (&grid);
   dim = ORDER/grid.gridOrder;

   localA=Allocate2DMatrix(dim,dim);
   if (localA==NULL) return (-1);
   localB=Allocate2DMatrix(dim,dim);
   if (localB==NULL) return (-1);
   localC=Allocate2DMatrix(dim,dim);
   if (localC==NULL) return (-1);

   if (rank==root) {
       aMatrix=Allocate2DMatrix(ORDER,ORDER);
       bMatrix=Allocate2DMatrix(ORDER,ORDER);
       cMatrix=Allocate2DMatrix(ORDER,ORDER);

       if ((!aMatrix)||(!bMatrix)||(!cMatrix)) {
           printf ("Not enough memory. Aborting...\n");
           MPI_Finalize();
           return (-1); }

       for (i=0;i<ORDER;i++) {
            for (j=0;j<ORDER;j++) {
               aMatrix[i][j]=(double)rand()/RAND_MAX;
               bMatrix[i][j]=(double)rand()/RAND_MAX;
               cMatrix[i][j]=0.0; }}
       printf ("Matrix A data\n");
       for (i=0;i<ORDER;i++) {
            for (j=0;j<ORDER;j++)
                 printf ("%.2f ", aMatrix[i][j]);
       printf ("\n"); }

       printf ("Matrix B data\n");
       for (i=0;i<ORDER;i++) {
            for (j=0;j<ORDER;j++)
                 printf ("%.2f ", bMatrix[i][j]);
       printf ("\n"); }}

   Scatter2DMatrix (aMatrix, ORDER, localA, dim, root, &grid);
   Scatter2DMatrix (bMatrix, ORDER, localB, dim, root, &grid);
   Fox (ORDER, &grid, localA, localB, localC);
   Gather2DMatrix (cMatrix, ORDER, localC, dim, root, &grid);
   if (rank==root) {
       printf ("Matrix C data\n");
       for (i=0;i<ORDER;i++) {
            for (j=0;j<ORDER;j++)
                 printf ("%.2f ", cMatrix[i][j]);
       printf ("\n"); }}

   Free2DMatrix (localA, dim);
   Free2DMatrix (localB, dim);
   Free2DMatrix (localC, dim);

   MPI_Barrier (MPI_COMM_WORLD);

   if (rank==root) {
       Free2DMatrix (aMatrix, ORDER);
       Free2DMatrix (bMatrix, ORDER);
       Free2DMatrix (cMatrix, ORDER); }

   MPI_Comm_free (&grid.gridComm);
   MPI_Comm_free (&grid.rowComm);
   MPI_Comm_free (&grid.colComm);
   MPI_Finalize();
   return (0); }
