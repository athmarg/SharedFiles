#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>

#define HEADSIZE 14 
#define INFOSIZE 40

typedef struct tagBITMAPFILEHEADER {
    uint16_t bfType;
    uint32_t bfSize;
    uint16_t bfReserved1;
    uint16_t bfReserved2;
    uint32_t bfOffBits;
} BITMAPFILEHEADER;

// BITMAPINFOHEADER 40bytes
typedef struct tagBITMAPINFOHEADER{
    uint32_t biSize;
    int32_t biWidth;
    int32_t biHeight;
    uint16_t biPlanes;
    uint16_t biBitCount;
    uint32_t biCompression;
    uint32_t biSizeImage;
    int32_t biXPixPerMeter;
    int32_t biYPixPerMeter;
    uint32_t biClrUsed;
    uint32_t biClrImporant;
    } BITMAPINFOHEADER;                         
                                         
typedef struct tagRGBQUAD {              
    uint8_t  rgbBlue;                    
    uint8_t  rgbGreen;                   
    uint8_t  rgbRed;                     
    uint8_t  rgbReserved;                
    } RGBQUAD; 

int GetBitmapDataOffset (char * fileName) {
   FILE * fp; BITMAPFILEHEADER bmpHeader={0};
   fp = fopen (fileName, "rb");
   if (!fp) {
       printf ("Bitmap File could not be Opened\n");
       return (-1); }
   rewind (fp);
   fread (&bmpHeader, HEADSIZE, 1, fp);
   fclose (fp);
   return (bmpHeader.bfOffBits); }
  
int GetBitmapColorNumber (char * fileName) {
   FILE * fp;
   int colors;
   BITMAPFILEHEADER bmpHeader={0};
   BITMAPINFOHEADER bmpInfo={0};
   fp = fopen (fileName, "rb");
   if (!fp) {
       printf ("Bitmap File could not be Opened\n");
       return (-1); }
   rewind (fp);
   fread (&bmpHeader, HEADSIZE, 1, fp);
   fread (&bmpInfo, INFOSIZE,1,fp);
   fclose (fp);
   if (bmpInfo.biBitCount<=8)
       colors = (int)pow(2,bmpInfo.biBitCount);
   else colors = 0;
   return (colors); }

 int GetBitmapWidth (char * fileName) {
   FILE * fp; BITMAPFILEHEADER bmpHeader={0};
   BITMAPINFOHEADER bmpInfo={0};
   fp = fopen (fileName, "rb");
   if (!fp) {
       printf ("Bitmap File could not be Opened\n");
       return (-1); }
   rewind (fp);
   fread (&bmpHeader, HEADSIZE, 1, fp);
   fread (&bmpInfo, INFOSIZE,1,fp);
   fclose (fp);
   return (bmpInfo.biWidth); }

 int GetBitmapHeight (char * fileName) {
   FILE * fp;
   BITMAPFILEHEADER bmpHeader={0};
   BITMAPINFOHEADER bmpInfo={0};
   fp = fopen (fileName, "rb");
   if (!fp) {
       printf ("Bitmap File could not be Opened\n");
       return (-1); }
   rewind (fp);
   fread (&bmpHeader, HEADSIZE, 1, fp);
   fread (&bmpInfo, INFOSIZE,1,fp);
   fclose (fp);
   return (bmpInfo.biHeight); }
  
RGBQUAD * GetBitmapColorPalette (char * fileName) {
   FILE * fp;
   int colorNumber;
   RGBQUAD * rgbTable = NULL;
   BITMAPFILEHEADER bmpHeader={0};
   BITMAPINFOHEADER bmpInfo={0};
   fp = fopen (fileName, "rb");
   if (!fp) {
       printf ("Bitmap File could not be Opened\n");
       return (NULL); }
   rewind (fp);
   fread (&bmpHeader, HEADSIZE, 1, fp);
   fread (&bmpInfo, INFOSIZE,1,fp);
   if (bmpInfo.biBitCount<=8)
       colorNumber = (int) pow (2, bmpInfo.biBitCount);
   else colorNumber = 0;
   if (colorNumber) {
       rgbTable=(RGBQUAD *)calloc(colorNumber,sizeof(RGBQUAD));
       if (!rgbTable) return (NULL);
       fread (rgbTable, sizeof(RGBQUAD), colorNumber, fp); }
   fclose (fp);
   if (!colorNumber) return (NULL);
   return (rgbTable);}  
  
int main (int argc, char ** argv) {
  int colors, width, height;
  char * pixels; int rank, size, offset;
  int rows, count, counter, index;
  char fileName [64] = "./clouds.bmp";
  RGBQUAD * palette;
  long int localEdgePixels=0, totalEdgePixels;
  MPI_File fileHandle;
  MPI_Status status;
  MPI_Offset offset1, offset2;
  double threshold = 15.0;
  double distance1, distance2;
  int color, color1, color2;
  int red, green, blue;
  int red1, green1, blue1, red2, green2, blue2;
  int disp = HEADSIZE + INFOSIZE;
 

  MPI_Init (&argc, &argv);
  MPI_Comm_rank (MPI_COMM_WORLD, &rank);
  MPI_Comm_size (MPI_COMM_WORLD, &size);

  if (rank==0) { 
      colors = GetBitmapColorNumber (fileName);
      width = GetBitmapWidth (fileName);
      height = GetBitmapHeight (fileName);
      offset = GetBitmapDataOffset (fileName); 
      printf ("Proc %d => colors=%d, width=%d, height=%d, size=%d\n",rank, colors,width,height,disp);  }

  MPI_Bcast (&colors, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast (&width, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast (&height, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast (&offset, 1, MPI_INT, 0, MPI_COMM_WORLD);

  MPI_File_open (MPI_COMM_WORLD, fileName, MPI_MODE_RDWR, MPI_INFO_NULL, &fileHandle);
  MPI_File_seek (fileHandle, disp, MPI_SEEK_SET);
  palette=(RGBQUAD *)calloc(colors,sizeof(RGBQUAD));
  MPI_File_read (fileHandle, palette, 4*colors, MPI_BYTE, &status);
  MPI_Get_elements (&status, MPI_BYTE, &count);
 
  if (rank==0) {
      for (counter=0;counter<15;counter++)
           printf ("Color %03d ===> RED %03d GREEN %03d BLUE %03d\n", 
                    counter, palette[counter].rgbRed, palette[counter].rgbGreen, palette[counter].rgbBlue); }
 if ((height%size)) {
      if (rank==0)
          printf ("Bitmap height must be an integer multiple of process number\n");
          MPI_Finalize ();
      return (-1); }

  rows = height/size;
  pixels = (char *) malloc (rows*width*sizeof(char));
  if (!pixels) {
      printf ("No memory available\n");
      MPI_Finalize ();
      return (-2); }

  MPI_File_seek (fileHandle, offset+rank*rows*width, MPI_SEEK_SET);
  MPI_File_get_position (fileHandle, &offset1);
  MPI_File_read (fileHandle, pixels, rows*width, MPI_BYTE, &status);
  MPI_File_get_position (fileHandle, &offset2);
  MPI_Get_elements (&status, MPI_BYTE, &count);
  printf ("Process %d read %d items of color palette\n", rank,count);
 
  MPI_File_close (&fileHandle);

  for (counter=0;counter<rows-1;counter++) {
       for (index=0;index<width-1;index++) {
            color = pixels[counter*width+index];
            color1 = pixels[counter*width+index+1];
            color2 = pixels[(counter+1)*width+index];
            red = palette[color].rgbRed;
            green = palette[color].rgbGreen;
            blue = palette[color].rgbBlue;
            red1 = palette[color1].rgbRed;
            green1 = palette[color1].rgbGreen;
            blue1 = palette[color1].rgbBlue;
            red2 = palette[color2].rgbRed;
            green2 = palette[color2].rgbGreen;
            blue2 = palette[color2].rgbBlue;
            distance1=sqrt(pow((red-red1),2)+pow((green-green1),2) + pow((blue-blue1),2));

    distance2=sqrt(pow((red-red2),2)+pow((green-green2),2)+ pow((blue-blue2),2));
    if ((distance1>=threshold)||(distance2>=threshold))
         localEdgePixels++; }}
  printf ("%ld edge pixels out of %d pixels detected from process %d\n", localEdgePixels, (rows-1)*(width-1), rank);
  MPI_Reduce (&localEdgePixels, &totalEdgePixels, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
  if (rank==0)
      printf ("\n%ld edge pixels found in file %s out of %d total pixels\n", totalEdgePixels, fileName, (width-1)*(height-1));
  free (pixels);
  free (palette);
  MPI_Finalize ();
  return (0); }  
  
  
  
  
  
  
  
  
  
  
  
  
  
