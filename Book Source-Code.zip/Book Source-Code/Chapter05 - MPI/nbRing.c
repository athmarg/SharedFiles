#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LENGTH 512

int main (int argc,char * argv[]){
    int counter, rank, size;
    double sendBuffer [LENGTH], recvBuffer [LENGTH];
    double startTime, endTime;
    MPI_Request sendReq, recvReq;
    MPI_Status status;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD,&rank);
    MPI_Comm_size (MPI_COMM_WORLD,&size);

    srand ((unsigned)time(NULL)+rank);
    for (counter=0;counter<LENGTH;counter++) {
         sendBuffer[counter]=(double)rand()/RAND_MAX;
         recvBuffer[counter]=(double)0; }

    startTime = MPI_Wtime();
    if (rank==0) {
        MPI_Isend (sendBuffer, LENGTH, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &sendReq);
        MPI_Irecv (recvBuffer, LENGTH, MPI_DOUBLE, size-1, MPI_ANY_TAG, MPI_COMM_WORLD, &recvReq);
        endTime = MPI_Wtime(); }
    else if (rank==size-1) {
        MPI_Isend (sendBuffer, LENGTH, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, &sendReq);
        MPI_Irecv (recvBuffer, LENGTH, MPI_DOUBLE, rank-1, MPI_ANY_TAG, MPI_COMM_WORLD, &recvReq);
        endTime = MPI_Wtime(); }
    else {
        MPI_Isend (sendBuffer, LENGTH, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &sendReq);
        MPI_Irecv (recvBuffer, LENGTH, MPI_DOUBLE, rank-1, MPI_ANY_TAG, MPI_COMM_WORLD, &recvReq);
        endTime = MPI_Wtime(); }
    printf ("Process %d ==> Send Time = %.6f Recv Time = %.6f Duration = %.9f seconds\n", 
             rank, startTime, endTime, endTime-startTime);
    MPI_Wait (&sendReq, &status);
    MPI_Wait (&recvReq, &status);
    MPI_Finalize();
    return (0); }
    
    
    
