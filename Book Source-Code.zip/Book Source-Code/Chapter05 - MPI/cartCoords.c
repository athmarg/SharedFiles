#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main (int argc, char ** argv) {
    MPI_Comm cartComm;
    int counter, rank, size;
    int dims [3] = {2,3,2}, coords [3];
    int periodic [3] = {true, false, true};
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Cart_create (MPI_COMM_WORLD, 3, dims,
             periodic, true, &cartComm);
    if (rank==0) {
        for (counter=0;counter<size;counter++) {
             MPI_Cart_coords (cartComm, counter, 3, coords);
             printf ("Process %02d has coordinates (%d,%d,%d)\n",
                     counter, coords[0], coords[1],
                     coords[2]); }}
    MPI_Finalize();
    return (0); }
    
    
    
