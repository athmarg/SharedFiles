#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ROWS 8
#define COLS 8

int main (int argc, char ** argv) {
    int counter, index, rank, size;
    double aMatrix[ROWS][COLS];
    double bMatrix[ROWS][COLS];
    double tempRowA[COLS], rowA[COLS];
    double tempRowB[COLS], rowB[COLS];
    MPI_Win aRowWin, bRowWin;
    int doubleSize;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Type_size (MPI_DOUBLE, &doubleSize);

    if (size!=3) {
        printf ("Invalid process number. Aborting...\n");
        MPI_Abort (MPI_COMM_WORLD, (-1));}
    for (counter=0;counter<ROWS;counter++) {
         for (index=0;index<COLS;index++) {
              aMatrix[counter][index]=(double)rank;
              bMatrix[counter][index]=(double)rank; }}

    if (rank==0) {
        MPI_Win_create (tempRowA, ROWS*doubleSize, doubleSize,
                MPI_INFO_NULL, MPI_COMM_WORLD, &aRowWin);
        MPI_Win_create (tempRowB, ROWS*doubleSize, doubleSize,
                MPI_INFO_NULL, MPI_COMM_WORLD, &bRowWin); }
    else {
       MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
               MPI_COMM_WORLD, &aRowWin);
       MPI_Win_create (MPI_BOTTOM, 0, 1, MPI_INFO_NULL,
               MPI_COMM_WORLD, &bRowWin); }

    if (rank==1) {
        printf ("\nProcess %d data before the operation... \n",
                rank);
        for (counter=0;counter<ROWS;counter++) {
             for (index=0;index<COLS;index++)
                  printf ("%.1f ", aMatrix[counter][index]);
        printf ("\n"); }}

    if (rank==2) {
        printf ("\nProcess %d data before the operation \n",
                rank);
        for (counter=0;counter<ROWS;counter++) {
             for (index=0;index<COLS;index++)
                  printf ("%.1f ", bMatrix[counter][index]);
        printf ("\n"); }}
    for (counter=0;counter<ROWS;counter++) {
         for (index=0;index<COLS;index++) {
              if (rank==1)
                  rowA[index]=aMatrix[counter][index];
              if (rank==2)
                  rowB[index]=bMatrix[counter][index]; }
         if (rank==1) {
             MPI_Win_lock (MPI_LOCK_EXCLUSIVE, 0, 0, aRowWin);
             MPI_Put (rowA, COLS, MPI_DOUBLE, 0, 0, COLS,
                      MPI_DOUBLE, aRowWin);
             MPI_Win_unlock (0, aRowWin); }
         if (rank==2) {
             MPI_Win_lock (MPI_LOCK_EXCLUSIVE, 0, 0, bRowWin);
             MPI_Put (rowB, COLS, MPI_DOUBLE, 0, 0, COLS,
                      MPI_DOUBLE, bRowWin);
             MPI_Win_unlock (0, bRowWin); }
         if (rank==1) {
             MPI_Win_lock (MPI_LOCK_EXCLUSIVE, 0, 0, bRowWin);
             MPI_Get (rowB, COLS, MPI_DOUBLE, 0, 0, COLS,
                      MPI_DOUBLE, bRowWin);
             MPI_Win_unlock (0, bRowWin);
             for (index=0;index<COLS;index++)
                  aMatrix[counter][index]=rowB[index]; }
         if (rank==2) {
             MPI_Win_lock (MPI_LOCK_EXCLUSIVE, 0, 0, aRowWin);
             MPI_Get (rowA, COLS, MPI_DOUBLE, 0, 0, COLS,
                      MPI_DOUBLE, aRowWin);
             MPI_Win_unlock (0, aRowWin);
             for (index=0;index<COLS;index++)
                  bMatrix[counter][index]=rowA[index]; }}

    if (rank==1) {
       printf ("\nProcess %d data after the operation... \n",
               rank);
       for (counter=0;counter<ROWS;counter++) {
            for (index=0;index<COLS;index++)
                 printf ("%.1f ", aMatrix[counter][index]);
       printf ("\n"); }}
    if (rank==2) {
       printf ("\nProcess %d data after the operation \n",
               rank);
       for (counter=0;counter<ROWS;counter++) {
            for (index=0;index<COLS;index++)
                 printf ("%.1f ", bMatrix[counter][index]);
       printf ("\n"); }}

    MPI_Finalize();
    return (0); }
