#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fstream>

using namespace std;

#define N 4
#define M 3
#define K 75

#define localProcess 10
#define remoteProcess 20
#define unknownProcess 30
#define INTERCOMM_TAG 100

double GetInput (char * fileName, int pattern, int input) {
   fstream fin; int counter; double dVal;
   fin.open(fileName, ios::in);
   if (!fin) return(-1);
   fin.seekp(0, ios::beg);
   for (counter=0;counter<pattern*N;counter++)
   fin >> dVal;
   for (counter=0;counter<=input;counter++)
   fin >> dVal;
   return (dVal); }

int main (int argc, char ** argv) {
   int rank, newRank, size;
   int type, nextPattern;
   int counter, index;
   double input,inputValues [N];
   double mean, max, min;
   MPI_Comm intraComm, interComm1;
   bool usedPatterns [K];
   char dataSet [64] = "vectors.dat";
   MPI_Status status;
   MPI_Init (&argc, &argv);
   MPI_Comm_rank (MPI_COMM_WORLD, &rank);
   MPI_Comm_size (MPI_COMM_WORLD, &size);
   if (size!=(N+M)) {
      if (rank==0)
          printf ("Invalid Process Number\n");
      MPI_Finalize ();
      return (-1); }
   if ((rank>=0)&&(rank<N))
        type = localProcess;
   else if ((rank>=N)&&(rank<N+M))
        type = remoteProcess;
   else { type = unknownProcess;
        printf ("Process rank is invalid.\n");
        MPI_Finalize();
        return (-1); }
   MPI_Comm_split (MPI_COMM_WORLD, type, rank, &intraComm);
   MPI_Comm_rank (intraComm, &newRank);
   if (type==localProcess)
       MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, N, INTERCOMM_TAG, &interComm1);
   if (type==remoteProcess)
       MPI_Intercomm_create (intraComm, 0, MPI_COMM_WORLD, 0, INTERCOMM_TAG, &interComm1);
   for (counter=0;counter<K;counter++)
        usedPatterns [counter] = false;
   for (counter=0;counter<K;counter++) {
        if (rank==0) {
            do
               nextPattern=(int)((rand()*(K-1))/RAND_MAX);
            while (usedPatterns[nextPattern]==true);
            usedPatterns[nextPattern] = true; }
       MPI_Bcast (&nextPattern, 1, MPI_INT, 0, intraComm);
       if (type==localProcess) {
           input = GetInput (dataSet, nextPattern, rank);
           MPI_Gather (&input, 1, MPI_DOUBLE, inputValues, 1, MPI_DOUBLE, 0, intraComm);
           if (rank==0) {
               MPI_Send (inputValues, N, MPI_DOUBLE, 0, INTERCOMM_TAG, interComm1); }}
       if (type==remoteProcess) {
           if (newRank==0) {
               MPI_Recv (inputValues, N, MPI_DOUBLE, 0, INTERCOMM_TAG, interComm1, &status); }
       MPI_Bcast (inputValues, N, MPI_DOUBLE, 0, intraComm);
       printf ("Proc.%02d Data : ", rank);
       for (index=0;index<N;index++)
            printf ("%.3f ", inputValues[index]);
       if (newRank==0) {
           mean = 0.0;
           for (index=0;index<N;index++)
                mean += inputValues [index];
           mean /= N;
           printf ("Mean Value is %.2f\n", mean); }
       if (newRank==1) {
           min = inputValues [0];
           for (index=0;index<N;index++)
                if (inputValues[index]<min)
                    min = inputValues [index];
           printf ("Min value is %.2f\n", min); }
       if (newRank==2) {
           max = inputValues [0];
           for (index=0;index<N;index++)
                if (inputValues[index]>max)
                    max = inputValues [index];
       printf ("Max value is %.2f\n", max); }}}
   MPI_Comm_free (&intraComm);
   MPI_Comm_free (&interComm1);
   MPI_Finalize();
   return (0); }
   
