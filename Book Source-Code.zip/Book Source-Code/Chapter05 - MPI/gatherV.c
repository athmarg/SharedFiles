#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM 8
#define STRIDE 12


int main (int argc, char ** argv) {
    int i, j, rank, size, root = 0;
    double aMatrix[DIM][DIM];
    double * sendPtr, * recvBuffer;
    int * displacements, * recvCounts;
    MPI_Datatype newType;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (size!=DIM) {
        if (rank==0)
            printf ("Invalid process number.\n");
        MPI_Finalize ();
        return (-1); }
    for (i=0;i<DIM;i++) {
         for (j=0;j<DIM;j++) {
              aMatrix[i][j]=(double)rand()/RAND_MAX; }}
    recvBuffer = (double *) malloc (STRIDE*size*sizeof(double));
    if (!recvBuffer) {
         if (rank==0)
             printf ("Not enough memory ...\n");
         MPI_Finalize();
         return (-2); }
    for (i=0;i<(STRIDE*size);i++) recvBuffer[i]=-1;
    displacements = (int *) malloc (size*sizeof(int));
    if (!displacements) {
        if (rank==0)
            printf ("Not enough memory ...\n");
         MPI_Finalize();
         return (-2); }
    recvCounts = (int *) malloc (size*sizeof(int));
    if (!recvCounts) {
        if (rank==0)
            printf ("Not enough memory ...\n");
         MPI_Finalize();
         return (-2); }
    for (i=0;i<size;i++) {
         displacements[i] = i*STRIDE;
         recvCounts[i] = DIM-i; }
    MPI_Type_vector (1,DIM-rank,STRIDE,MPI_DOUBLE,&newType);
    MPI_Type_commit (&newType);
    sendPtr = &aMatrix[rank][rank];
    MPI_Gatherv (sendPtr, 1, newType, recvBuffer, recvCounts,
        displacements, MPI_DOUBLE, root, MPI_COMM_WORLD);
    if (rank==0) {
        printf ("MATRIX A ELEMENTS\n");
        for (i=0;i<DIM;i++) {
             printf ("\n");
             for (j=0;j<DIM;j++) {
                  printf ("%.3f ", aMatrix[i][j]); }}
     printf ("\n\nRECEIVE BUFFER ELEMENTS...\n");
     for (i=0;i<STRIDE*size;i++)
          printf ("%.3f ", recvBuffer[i]); }
    MPI_Type_free (&newType);
    MPI_Finalize ();
    return (0); }
