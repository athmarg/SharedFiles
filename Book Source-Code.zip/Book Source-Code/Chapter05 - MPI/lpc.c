/* Source File lpc.c */

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LPC_ORDER 8

void autoCorr (int fSize, double * frame, int lpcOrder,
               double * autoCorr) {
 int counter,index; double sum;
 for (counter=0;counter<=lpcOrder;counter++) {
      sum=0.0;
       for (index=0;index<(fSize-counter);index++)
            sum += frame[index]*frame[index+counter];
       autoCorr[counter]=sum; }}

void lpcCoding (int fSize, double * frame, 
                double * lpcVector) {
  double temp[LPC_ORDER+1],e[LPC_ORDER+1], sum;
  double lpcMatrix[LPC_ORDER+1][LPC_ORDER+1];
  int counter,index;
  e[0]=frame[0];
  if (e[0]==0) e[0]=0.001;
  for (counter=1;counter<=LPC_ORDER;++counter) {
     sum = 0.0;
     for (index=1;index<=(counter-1);++index)
          sum += lpcMatrix[index][counter-1]*
                          frame[counter-index];
     if (e[counter-1]==0)
         e[counter-1]=0.001;
     temp[counter]=(frame[counter]-sum)/e[counter-1];
     lpcMatrix[counter][counter]=temp[counter];
     for(index=1;index<counter;++index)
         lpcMatrix[index][counter]=
             lpcMatrix[index][counter-1]-temp[counter]*
                   lpcMatrix[counter-index][counter-1];
     e[counter]=(1-temp[counter]*temp[counter])*
         e[counter-1]; }
  for (counter=1;counter<=LPC_ORDER;++counter)
         lpcVector[counter]=
                   lpcMatrix[counter][LPC_ORDER]; }

int main(int argc, char * argv[]) {
    int rank, size, samples;
    int counter, index, frames;
    MPI_Comm interComm;
    MPI_Status status;
    double * currentFrame;
    double lpcCoefficients [LPC_ORDER+1];
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Comm_get_parent (&interComm);
    if (interComm==MPI_COMM_NULL) {
        printf ("Parent Comm does not exist.\n");
        MPI_Finalize();
        return (-1); }
    if (rank==0) {
        MPI_Recv (&frames, 1, MPI_INT, 0, 0, 
                  interComm, &status);
        MPI_Recv (&samples, 1, MPI_INT, 0, 0, 
                  interComm, &status); }
    MPI_Bcast (&frames, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&samples, 1, MPI_INT, 0, MPI_COMM_WORLD);
    currentFrame = (double *) malloc (samples*sizeof(double));
    for (counter=0;counter<frames;counter++) {
         if (rank==0)
             MPI_Recv (currentFrame, samples, 
                       MPI_DOUBLE, 0, 0, interComm, &status);
    MPI_Bcast (currentFrame, samples, MPI_DOUBLE, 0,
               MPI_COMM_WORLD);
    lpcCoding (samples, currentFrame, lpcCoefficients);
    MPI_Bcast (lpcCoefficients, LPC_ORDER+1, MPI_DOUBLE,
               0, MPI_COMM_WORLD);
    printf ("Fr%02d LPC > ", counter);
    for (index=1;index<=LPC_ORDER;index++)
         printf ("%+2.3f ", lpcCoefficients[index]);
    printf ("\n"); }
    free (currentFrame);
    MPI_Finalize();
    return 0; }
