#include <mpi.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#define N 100

int main (int argc, char ** argv) {
    double x[N], y[N];
    int i; double sum=0.0, total=0.0;
    int rank, size, k;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (N%size) {
        printf ("Invalid Process Number....\n");
        return (-1); }
    k = N/size;
    for (i=0;i<N;i++) {
         x[i]=(double)rand()/RAND_MAX;
         y[i]=(double)rand()/RAND_MAX; }
    for (i=rank*k;i<=(rank+1)*k-1;i++)
         sum += x[i]*y[i];
    printf ("Process %02d used cells [%02d, %02d] and estimated a partial sum of %02.03f\n",
             rank, rank*k, (rank+1)*k-1, sum);
    MPI_Reduce(&sum,&total,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    if (rank==0) 
        printf ("Inner Vector Product is %f\n", total);
    MPI_Finalize();
    return (0); }
    
    
    
    
    
    
    
