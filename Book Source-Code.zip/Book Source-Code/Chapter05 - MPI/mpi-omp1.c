#include <mpi.h>
#include <omp.h>
#include <stdio.h> 

#define THREADS 4

int main(int argc, char *argv[]) {
    int mpiRank, ompRank, provided;
    MPI_Init_thread (&argc, &argv, MPI_THREAD_FUNNELED, &provided);
    MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
    #pragma omp parallel num_threads(THREADS) private(ompRank)
      {
         ompRank = omp_get_thread_num();
         printf("I'm thread %d in process %d\n", ompRank, mpiRank);
      }
    MPI_Finalize(); }
    
    
    
    
