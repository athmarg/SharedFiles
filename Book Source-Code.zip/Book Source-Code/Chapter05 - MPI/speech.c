#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI (4.0)*atan(1.0)

#define SAMPLES     512
#define FRAMESIZE    64
#define HAMMING      01
#define HANNING      02

void HammingWindow (int N, double * window) {
     int counter;
     for (counter=0;counter<N;counter++)
         window[counter]=
               0.54-0.46*cos((2*PI*counter)/(N-1)); }

int main(int argc, char * argv[]) {
    int rank, size, counter, frames;
    int loop, samples = FRAMESIZE;
    double buffer [SAMPLES], window [FRAMESIZE];
    double currentFrame [FRAMESIZE];
    char fileName [64] = "speech.dat";
    MPI_Comm interComm;
    char * commands [2]={"./lpc","./cps"};
    char * argvLPC [] = {"-saveFile", "lpc.dat", (char *)0};
    char * argvCPS [] = {"-saveFile", "cps.dat", (char *)0};
    char ** argvs [2] = {argvLPC, argvCPS};
    MPI_Info infos [2] = {MPI_INFO_NULL, MPI_INFO_NULL};
    int maxProcs [3] = {1, 1};
    int windowType = HAMMING;
    FILE * fp;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    if (SAMPLES%FRAMESIZE) {
        MPI_Finalize ();
        return (-1); }
    frames = SAMPLES/FRAMESIZE;
    if (rank==0) {
        fp = fopen (fileName,"r");
        if (!fp) {
            MPI_Finalize();
            return (-1); }
        rewind (fp);
        for (counter=0;counter<SAMPLES;counter++) 
             fscanf (fp,"%lf",&buffer[counter]);
        fclose(fp); }
    MPI_Bcast (buffer, SAMPLES, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    if (windowType==HAMMING)
        HammingWindow (FRAMESIZE, window);
    MPI_Comm_spawn_multiple (2, commands, argvs, maxProcs,
            infos, 0, MPI_COMM_WORLD, &interComm, NULL);
    MPI_Send (&frames, 1, MPI_INT, 0, 0, interComm);
    MPI_Send (&samples, 1, MPI_INT, 0, 0, interComm);
    loop = 0;
    do {
         for (counter=0;counter<FRAMESIZE;counter++) {
              currentFrame[counter] =
                    buffer[loop*FRAMESIZE+counter];
              currentFrame[counter] *= window [counter]; }
         MPI_Send (currentFrame, FRAMESIZE, MPI_DOUBLE,
                   0, 0, interComm);
         loop++;
       } while (loop<frames);
    MPI_Finalize ();
    return (0); }
    
    
