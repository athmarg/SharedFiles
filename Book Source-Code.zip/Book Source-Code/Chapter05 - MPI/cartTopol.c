#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define DIM 3

int main (int argc, char ** argv) {
    MPI_Comm cartComm;
    int counter, rank, size;
    int dims [DIM] = {2,3,2};
    int periodic [DIM] = {true, false, true};
    int cartDim, * dim, * periods, * coords;
    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &size);
    MPI_Cart_create (MPI_COMM_WORLD, DIM, dims,
                     periodic, true, &cartComm);
    MPI_Cartdim_get (cartComm, &cartDim);
    dim = (int *) malloc (cartDim*sizeof(int));
    periods = (int *) malloc (cartDim*sizeof(int));
    coords = (int *) malloc (cartDim*sizeof(int));
    MPI_Cart_get (cartComm, cartDim, dim, periods, coords);
    if (rank==0) {
        printf ("Cartesian Topology Dimension is %d\n",
                 cartDim);
        for (counter=0;counter<cartDim;counter++)
             printf ("Dim[%d]=%d ", counter, dim[counter]);
        printf ("\n");
        for (counter=0;counter<cartDim;counter++)
             printf ("Periods[%d]=%d ", counter, periods[counter]);
        printf ("\n"); }
    printf ("Process %d Cartesian Coordinates\n", rank);
    for (counter=0;counter<cartDim;counter++)
         printf ("Coords[%d]=%d ", counter, coords[counter]);
    printf ("\n");
    free (dim); free (periods); free (coords);
    MPI_Finalize();
    return (0); }
    
    
    
    
    
