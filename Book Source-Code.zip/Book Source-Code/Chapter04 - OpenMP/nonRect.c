#include <stdio.h>
#define M 10
#define N 20

extern void initmatrix (int m, int n, float a[m][n+2]) {
   for (int i=0;i<m;i++)
        for (int j=0;j<n+2;j++) 
        a[i][j]=i+j; }

int main(){
  float a[M][N+2], b[M][M];
  initmatrix (M,N,a);

  #pragma omp parallel for collapse(2) num_threads(2) 
  for (int i=0;i<M;i++)
     for (int j=i;j<M; j++) {
        float temp = 0.0f;
        for (int k=0;k<N;k++)
             temp += (a[i][k]-a[i][N])*(a[j][k]-a[j][N]);
        b[i][j] = temp/(a[i][N+1]*a[j][N+1]*(N-1));
        b[j][i] = b[i][j]; }

  printf ("b[0][0] = %f, b[M-1][M-1] = %f\n", 
           b[0][0], b[M-1][M-1]);
  return 0; }
  
  
  
  
