#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
 
void monteCarlo (int points, int threads) {
    double x, y, d, pi;
    int i = 0, pCircle = 0, pSquare = 0;
 
#pragma omp parallel firstprivate(x, y) \
        reduction(+ : pCircle, pSquare) \
        num_threads(threads)
    {
        srand((int)time(NULL));
        for (i = 0; i < points; i++) {
            x = (double)rand()/RAND_MAX;
            y = (double)rand()/RAND_MAX;
            d = pow(x,2)+pow(y,2);
            if (d <= 1) pCircle++;
            pSquare++; }}

    pi = 4.0 * ((double)pCircle / (double)(pSquare));
    printf("The estimated value of Pi is %f\n", pi); }
 
int main(int argc, char ** argv) {
    long int randPoints, threads;
    if (argc==1) {
        randPoints = 100000;
        threads = 2; }
    else {
      randPoints = strtol(argv[1],NULL,10);
      threads = strtol(argv[2],NULL,10); }
    monteCarlo(randPoints, threads); }
    
    
