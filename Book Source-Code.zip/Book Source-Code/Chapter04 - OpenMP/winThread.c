#include <windows.h>
#include <stdio.h>

DWORD WINAPI ThreadFunc (void* data) {
   printf ("Hello from the new thread\n");
   return 0; }

int main() {
   printf ("Hello from the main thread\n");
   HANDLE thread = CreateThread (NULL, 0, ThreadFunc, NULL, 0, NULL);
   if (thread)
   WaitForSingleObject(thread, INFINITE); }
