#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   
   printf("Hello World!\n");
   return 0;
}