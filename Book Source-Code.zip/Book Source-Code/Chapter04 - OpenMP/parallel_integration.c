#include <omp.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

double func (double x) {
       return (3*pow(x,2)+1); }
       
void CalcIntegral (double a, double b, long int N, double *totalIntegral) {
    double x, localIntegral=0.0;
    double base = (b-a)/N;
    int rank = omp_get_thread_num();
    int size = omp_get_num_threads();
    long int i, localN = N/size;
    double localA = a+rank*localN*base;
    double localB = localA + localN*base;
    localIntegral = (func(localA)+func(localB))/2.0;
    x=localA;
    for (i=1;i<localN-1;i++) {
         x=x+base;
         localIntegral += func(x); }
    localIntegral = localIntegral*base;
    printf ("Thread %d ==> Local A = %lf, Local B = %lf, Local N=%ld\n", rank, localA, localB, localN);
    printf ("Local Integral for Thread %d is %lf\n", rank, localIntegral);
    #pragma omp critical
    *totalIntegral += localIntegral; }       

void main (int argc, char ** argv) {
    double a,b, totalIntegral = 0.0;
    long int N, size;
    clock_t t1,t2;
    if (argc==1) size = 2;
    else size = strtol(argv[1],NULL,10);
    printf ("Number of threads is %ld\n", size);
    printf ("Give the value of a: "); scanf ("%lf", &a);
    printf ("Give the value of b: "); scanf ("%lf", &b);
    printf ("Give the value of N: "); scanf ("%ld", &N);
    t1 = clock();    
    #pragma omp parallel num_threads(size)
    CalcIntegral (a,b,N,&totalIntegral);
    t2 = clock()-t1;  
    printf ("Integral: %.6f (N=%ld, T=%.6f secs)\n",
            totalIntegral, N, ((double)t2)/CLOCKS_PER_SEC); }
            
            
            
            
            
            
            
            
