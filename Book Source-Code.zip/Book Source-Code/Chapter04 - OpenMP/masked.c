#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   int rank, size;
   #pragma omp parallel private(rank) num_threads(5)
   {
     rank = omp_get_thread_num(); 
     size = omp_get_num_threads();
     #pragma omp masked filter(1)
       {
           printf("Hello from thread %d of %d\n",
                   rank, size);  }}
   return 0; }
   
   
   
   
   
   
   
   
   
   
   
   


