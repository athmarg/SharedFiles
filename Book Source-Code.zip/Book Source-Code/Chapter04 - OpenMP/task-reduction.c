
#include<stdlib.h>
#include<stdio.h>

#define N 10

typedef struct node {
    int val;
    struct node *next; } node_t;

/* This function gets as argment the head of the list */
/* and returns the sum of the stored values           */

int listSum (node_t *p) {
    int res = 0;
    #pragma omp taskgroup task_reduction(+: res)
     {
        node_t* tmp = p;
        while (tmp!=0) {
               #pragma omp task in_reduction(+: res)
               res += tmp->val;
               tmp = tmp->next; }}
    return res; }


int main(int argc, char *argv[]) {
    int i;
    /* A linked list is dynamically created in this point */
    node_t * root = (node_t*) malloc (sizeof(node_t)); 
    root->val = 1; node_t* tmp = root;
    for(i=2;i<=N;++i){
        tmp->next = (node_t*) malloc(sizeof(node_t));
        tmp = tmp->next;
        tmp->val = i; }
    tmp->next = 0;
    /* The sum of the list data is created in parallel    */
    #pragma omp parallel
    #pragma omp single
      {
        int result = listSum (root);
        printf("The value of sum is %d\n", result); }
    /* The list must be freed before return               */
    return 0; }
    
    





