#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int is_prime (int number) {
   int factor, maxlimit = sqrt(number);
   for (factor=3;factor<=maxlimit;factor++) {
        if (number%factor!=0) continue; 
            else return 0; } 
   return 1; } 

int main (int argc, char ** argv) {
   int * buffer, i, print;
   long int maxN, count = 0;
   if (argc!=2) { maxN = 1000; }
   else { maxN=strtol (argv[1],NULL,10);
          if (maxN<3) maxN=3; }
   printf ("Range of search is [1, %ld]\n", maxN);
   buffer = (int *) malloc(sizeof(int) * maxN);
   if (!buffer) { printf ("Not enough memory\n"); return (-1); }
   for (i=0;i<maxN;i++) buffer[i] = 0; 
   for (i=3;i<maxN;i+=2) {
        if (is_prime (i)) {
            buffer[count]=i;
            count++; }}
  printf("Prime numbers found in range [1-%ld] is %ld\n", maxN,count); 
  for (i=0;i<count;i++) printf("%d ",buffer[i]);
  printf("\n");
  free(buffer); 
  return (0); }
  
  
  
