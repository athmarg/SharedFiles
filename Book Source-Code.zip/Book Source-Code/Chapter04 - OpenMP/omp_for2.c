#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   int rank, size, i;
   omp_set_num_threads(4);
   
   #pragma omp parallel private(rank)
   {
    rank = omp_get_thread_num(); 
    size = omp_get_num_threads();
    #pragma omp for schedule (static,2)
    for (i=1; i<=14; i++)
         printf("Thread %02d of %d ==> Iteration No %02d\n",
                 rank, size, i); }
   
   return 0; }
   
   
   
   
   
