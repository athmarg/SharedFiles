#include <omp.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define LENGTH 1000

double length (double * vector, int N) {
   int i; double temp = 0.0;
   for (i=0;i<N;i++) temp += pow(vector[i],2);
   return sqrt(temp); }

double min (double * vector, int N) {
   int i; double temp = vector[0];
   for (i=0;i<N;i++)
   if (vector[i]<temp) temp=vector[i];
   return temp; }

double max (double * vector, int N) {
   int i; double temp = vector[0];
   for (i=0;i<N;i++)
   if (vector[i]>temp) temp=vector[i];
   return temp; }

double average (double * vector, int N) {
   int i; double temp = 0.0;
   for (i=0;i<N;i++) temp += vector[i];
   return temp/N; }

void main (int argc, char ** argv) {
   long int i, threads;
   double len, minVal, maxVal, avg;
   double Vec[LENGTH];
   double t1,t2;
   if (argc==1) threads = omp_get_num_procs();
   else threads = strtol (argv[1],NULL,10);
   omp_set_num_threads (threads);
   printf ("Using %ld threads\n", threads);
   for (i=0;i<LENGTH;i++) {
        Vec[i]=(double)rand()/RAND_MAX;
        Vec[i]=(double)rand()/RAND_MAX; }
   #pragma omp parallel sections shared(Vec)
     {
       #pragma omp section /* this directive is optional */
         {
            len = length (Vec, LENGTH);
            printf ("Thread %d ==> Length is %f\n", omp_get_thread_num(), len); }
       #pragma omp section
         {
            minVal = min (Vec, LENGTH);
            printf ("Thread %d ==> Min is %f\n", omp_get_thread_num(), minVal); }
       #pragma omp section
         {
            maxVal = max (Vec, LENGTH);
            printf ("Thread %d ==> Max is %f\n", omp_get_thread_num(), maxVal); }
       #pragma omp section
         {
            avg = average (Vec, LENGTH);
            printf ("Thread %d ==> Average is %f\n", omp_get_thread_num(), avg); }}}
