#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main(int argc, char **argv) {
    long int iterations, threads;
    if (argc==1) {
        iterations = 100000;
        threads = 2; }
    else {
      iterations = strtol(argv[1],NULL,10);
      threads = strtol(argv[2],NULL,10); }
   double piValue=1.0, t1, t2;
   omp_set_num_threads(threads);
   t1 = omp_get_wtime();

   #pragma omp parallel for reduction(*:piValue)
      for (int i=1;i<=iterations;i++)
         piValue *= (double) (4*pow(i,2))/(double) (4*pow(i,2)-1);

   piValue *= 2;
   t2 = omp_get_wtime();
   printf("Estimated pi value is %.8f (Duration %.8f)\n", piValue, t2-t1); 
   return 0; }
    
    

