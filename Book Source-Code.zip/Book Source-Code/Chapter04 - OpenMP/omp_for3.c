#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   int rank, size, i;
   omp_set_num_threads(4);
   
   #pragma omp parallel private(rank)
   {
    rank = omp_get_thread_num(); 
    size = omp_get_num_threads();
    #pragma omp for schedule (static,2)
    for (int i=0; i<8; i++) {
         for (int j=0; j<4; j++) {
              printf("Thread %d ===> i = %0d, j = %d\n", 
                      rank, i, j); }}}
   
   return 0; }
   
   
   
   
   
