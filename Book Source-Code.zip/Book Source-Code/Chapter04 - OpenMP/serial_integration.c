#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

double func (double x) {
       return (3*pow(x,2)+1); }

void main (int argc, char ** argv) {
    double x, h, a = 1.0, b = 4.0, integral = 0.0;
    long int i, N;
    clock_t t1,t2;
    t1 = clock();    
    if (argc==1) N=10;
    else N = strtol(argv[1],NULL,10);
    h = (b-a)/N;
    integral = (func(a)+func(b))/2;
    x=a;
    for (i=1;i<N-1;i++) {
         x=x+h;
         integral=integral+func(x); }
    integral = integral * h;
    t2 = clock()-t1;  
    printf ("Function Integral (%ld trapezoids) has a value of %.6f (time elapsed %.6f secs)\n",
            N, integral, ((double)t2)/CLOCKS_PER_SEC); }
