#include <stdio.h>
#include <omp.h>
#include <math.h>
#include <stdlib.h>

int is_prime (int number, int * iterations) {
   int temp = 0, factor, maxlimit = sqrt(number);
   for (factor=3;factor<=maxlimit;factor++) {
        if (number%factor!=0) { temp++; continue; }
            else return 0; } 
   *iterations = temp;
   return 1; } 

int main( int argc , char **argv) {
   int i, count = 0, threads, iterations, * buffer, * iters;
   long int total = 0, maxN; int rank;
   if (argc!=3) { threads = 8; maxN = 1000; }
   threads=atoi(argv[1]);
   maxN=strtol(argv[2],NULL,10);
   if (maxN<3) maxN=3;
   printf ("Thread number ==> %d, range is [1, %ld]\n", 
            threads, maxN);
   buffer = (int *) malloc(sizeof(int) * maxN);
   iters = (int *) malloc(sizeof(int) * maxN);   
   if ((!buffer)||(!iters)) { 
        printf ("Not enough memory\n"); 
        return (-1); }
   for (i=0;i<maxN;i++) { buffer[i] = 0; iters[i]=0; }
   rank = omp_get_thread_num();
   
   #pragma omp parallel num_threads(threads) \
                        private(iterations)  \
                        firstprivate(total)
   {
   double wtime = omp_get_wtime();
   #pragma omp for nowait 
   for (i=3;i<maxN;i+=2) {
        if (is_prime(i,&iterations)) {
         #pragma omp critical 
           {
            buffer[count]=i;
            iters[count]=iterations;            
            count++; total += iterations; }}}
                            
  wtime = omp_get_wtime() - wtime;
  printf ("Thread==> %d, Total is %ld (Time %f secs)\n", 
          omp_get_thread_num(), total, wtime);} 
   
  printf("Primes found in range [1-%ld] ==> %d\n", 
          maxN, count); 
  // for (i=0;i<count;i++) 
  //      printf("%d(%d) ",buffer[i], iters[i]);
  // printf("\n");
  total = 0.0;
  for (i=0;i<count;i++) total += iters[i];
  printf ("Total is %ld\n,", total) ;
  free(buffer); free (iters);
  return (0); }
  
  
  
