#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   
   #pragma omp parallel
    { 
      printf ("Hello World!\n");
      printf ("  Have a nice day\n"); }
   printf ("\nHello from main thread\n");
   return 0; }


