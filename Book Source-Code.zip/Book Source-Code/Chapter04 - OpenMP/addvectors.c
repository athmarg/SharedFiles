#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#define N 10000

int main (int argc, char ** argv) {
   long int rank, size, i, threads, chunk;
   double A[N], B[N], C[N];
   double t1,t2;
   char mode [20];

   if (argc==1) { 
       threads = omp_get_num_procs();
       chunk = 1; }
   else {
       threads = strtol (argv[1],NULL,10);
       chunk = strtol (argv[2],NULL,10); }
   rank=omp_get_thread_num();
   size=omp_get_num_threads();
   /* The main thread initializes vectors A and B */
   printf ("Using %ld threads with a chunk size of %ld\n", threads, chunk);
   for (i=0;i<N;i++) {
        A[i]=(double)rand()/RAND_MAX;
        B[i]=(double)rand()/RAND_MAX; }

   t1 = omp_get_wtime();
   #pragma parallel shared(A,B,C) private(i,rank) 
     { /* start of parallel code */
       #pragma omp for schedule (static,chunk)
       for (i=0;i<N;i++) C[i]=A[i]+B[i]; 
     } /* end of parallel code */
   t2 = omp_get_wtime();  

   printf ("Thread %ld: Process completed in %.12f sec\n", rank, t2-t1); 
   printf ("Printing some elements ...\n");
   for (i=0;i<3;i++) printf ("A[i]=%f B[i]=%f ==> C[i]=%f\n", A[i],B[i],C[i]); }
         


