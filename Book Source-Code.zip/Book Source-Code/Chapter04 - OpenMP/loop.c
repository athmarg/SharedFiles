#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#define N 15

int main()  {
  double a = 5.0, b=3.0; int rank;
  double *x = (double *)malloc(N*sizeof(double));
  double *y = (double *)malloc(N*sizeof(double));
  
  for (int i=0;i<N;i++) 
       x[i]=y[i]=(double)rand()/RAND_MAX;
  
  #pragma omp parallel num_threads(3)
  {
  rank = omp_get_thread_num();
  #pragma omp loop
   for (int i=0;i<N;++i) {
        printf ("Thread %d ==> Iteration %02d\n",rank,i);
        y[i]=a*x[i]+b*y[i]; }}}
        
        
         
         
         


        
        
        
        
        
