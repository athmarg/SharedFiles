#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv) {
   int threads;
   if (argc==1) threads = omp_get_num_procs();
   else threads = strtol (argv[1],NULL,10);
   
   #pragma omp parallel num_threads(threads)
     {
       printf ("Hello World!\n");
       printf (" Have a nice day\n"); }
   printf ("\nHello from main thread\n");
   return 0; }


