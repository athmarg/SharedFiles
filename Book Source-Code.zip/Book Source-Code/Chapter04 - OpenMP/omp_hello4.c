#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
   int rank, size;
   float a=5.6, b=6.8;
   
   #pragma omp parallel private(rank)
   {
     rank = omp_get_thread_num(); 
     size = omp_get_num_threads();
     if (rank==0) printf ("I am the main thread with thread id = %d\n", rank);
     if (rank==1) {
         printf ("My thread id is %d and I perform addition\n", rank);
         printf ("Thread %d ==> The sum of a and b is %f\n", rank, a+b); }
     if (rank==2) {
         printf ("My thread id is %d and I perform subtraction\n", rank);
         printf ("Thread %d ==> The difference of a and b is %f\n", rank, a-b); }         
     if (rank==3) {
         printf ("My thread id is %d and I perform multiplication\n", rank);
         printf ("Thread %d ==> The product of a and b is %f\n", rank, a*b); } }  
             
   return 0; }
   
   
   


