#include <stdio.h>
#include <omp.h>

int main(int argc, char **argv) {
  omp_set_max_active_levels (2);
  omp_set_dynamic (0); 
  #pragma omp parallel num_threads(2)
    {
      #pragma omp single
        printf("THREAD NUMBER IN OUTER REGION = %d\n", 
              omp_get_num_threads());  
      printf("Thread ID (Outer region): %d\n", 
             omp_get_thread_num());
      #pragma omp parallel num_threads(3) 
        {
          #pragma omp single
             printf("THREAD NUMBER IN INNER REGION = %d\n", 
                    omp_get_num_threads());
          printf("Thread ID (inner region): %d\n", 
                  omp_get_thread_num()); }}              
  return 0; }
   
   
   
   
   
   
