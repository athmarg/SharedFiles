#include <stdio.h>
#include <limits.h>
#include <omp.h>

#define N 100

struct complex {
  double real;
  double imag; };

void addComplex (struct complex * a, struct complex * b) {
   a->real = a->real+b->real;
   a->imag = a->imag+b->imag; }

#pragma omp declare reduction(sum : struct complex : \
        addComplex (&omp_out,&omp_in)) \
	initializer (omp_priv={0,0})

int main (void) {
struct complex psum={0,0}, sum={0,0}, buffer[N];
for (int i=0;i<N;i++) {
     buffer[i].real=(double)(i+1);
     buffer[i].imag=(double)(i+1); }
#pragma omp parallel num_threads(5) firstprivate(buffer) 
   {
        #pragma omp for reduction (sum:psum)
        for (int i=0;i<N;i++) 
             addComplex(&psum,&buffer[i]);
        #pragma omp single
        printf ("Thread %d ==> Real = %f, Imaginary = %f\n", 
            omp_get_thread_num(), psum.real, psum.imag); }}
            
            
            
            
            
            
            
