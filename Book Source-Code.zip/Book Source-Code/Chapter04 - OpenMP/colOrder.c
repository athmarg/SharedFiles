#include <omp.h>
#include <stdio.h>

#define M 6
#define N 5

int main (void) {
   int i,j;
   #pragma omp parallel num_threads(5)
     {
       #pragma omp for collapse(2) ordered \
          private(i,j)  schedule(static,3)
          for (i=1;i<=M;i++)
             for (j=1;j<=N;j++) {
                #pragma omp ordered
                printf ("Thread %d ==> i = %d, j = %d\n",
                        omp_get_thread_num(), i, j); }}}
                           
