#include <stdio.h>
#include <omp.h>
#include <math.h>
#include <stdlib.h>

int is_prime (int number, int * iterations) {
   int temp = 0, factor, maxlimit = sqrt(number);
   for (factor=3;factor<=maxlimit;factor++) {
        if (number%factor!=0) { temp++; continue; }
            else return 0; } 
   *iterations = temp;
   return 1; } 

int main (int argc, char ** argv) {
   int * buffer, i, * iters, iterations;
   long int maxN, count = 0;
   if (argc!=2) { maxN = 1000; }
   else { maxN=strtol (argv[1],NULL,10);
          if (maxN<3) maxN=3; }
   printf ("Range of search is [1, %ld]\n", maxN);
   buffer = (int *) malloc(sizeof(int) * maxN);
   iters = (int *) malloc(sizeof(int) * maxN);   
   if ((!buffer)||(!iters)) { printf ("Not enough memory\n"); return (-1); }
   for (i=0;i<maxN;i++) { buffer[i] = 0; iters[i] = 0; }
   for (i=3;i<maxN;i+=2) {
        iterations = 0;
        if (is_prime (i,&iterations)) {
            buffer[count]=i;
            iters[count]=iterations;
            count++; }}
  printf("Prime numbers found in range [1-%ld] is %ld\n", maxN,count); 
  for (i=0;i<count;i++) printf("%d(%d) ", buffer[i], iters[i]);
  printf("\n");
  free(buffer); free (iters);
  return (0); }
  
  
  
