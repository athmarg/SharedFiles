#include <iostream>
#include <thread>

void thread_function() {
    std::cout << "Hello from new thread\n"; }

int main() {
    std::thread t (&thread_function); 
    std::cout << "Hello from main thread\n";
    t.join();   
    return 0; }
    
    
    
    
    
    
    
    
    
    
    
