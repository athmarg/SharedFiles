#include<pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define BUF_SIZE 3
#define OPERATIONS 8

int buffer[BUF_SIZE];
int insert=0, rem=0, items=0;

pthread_mutex_t mut=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t var_cons=PTHREAD_COND_INITIALIZER;
pthread_cond_t var_prod=PTHREAD_COND_INITIALIZER;

void *producer (void *arg) {
   for (int i=1; i<=OPERATIONS; i++) {
        pthread_mutex_lock (&mut);
        if (items > BUF_SIZE) exit(EXIT_FAILURE);
        while (items == BUF_SIZE)
               pthread_cond_wait (&var_prod, &mut);
        buffer[insert] = i;
        insert = (insert+1) % BUF_SIZE;
        items++;
        pthread_mutex_unlock (&mut);
        pthread_cond_signal (&var_cons);
        printf ("producer: inserted %d\n", i); }
   printf ("producer quiting\n"); }
   
void *consumer(void *arg) {
   int i;
   while (1) {
      pthread_mutex_lock (&mut);
      if (items < 0) exit(1);
      while (items == 0) 
             pthread_cond_wait (&var_cons, &mut);
      i = buffer[rem];
      rem = (rem+1) % BUF_SIZE;
      items--;
      pthread_mutex_unlock (&mut);
      pthread_cond_signal (&var_prod);
      printf ("Consume value %d\n", i);}}

int main (int argc, char *argv[]) {
   pthread_t tid1, tid2;
   if (pthread_create (&tid1,NULL,producer,NULL) != 0) {
       printf ("Unable to create producer!\n");
       exit (EXIT_FAILURE); }
   if (pthread_create (&tid2,NULL,consumer,NULL) != 0) {
       fprintf (stderr, "Unable to create consumer!\n");
       exit (EXIT_FAILURE); }
   pthread_join (tid1,NULL);
   pthread_join (tid2,NULL);
   
   
printf ("Manager thread is terminating now ...\n");
return (0); }
