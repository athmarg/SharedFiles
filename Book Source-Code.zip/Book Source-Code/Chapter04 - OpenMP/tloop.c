#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <sys/time.h>

#define N 1000

double A[N][N], B[N][N], C[N][N];

int main (int argc, char ** argv) {
    int i,j,k,threads,chunk;
   if (argc==1) { 
       threads = omp_get_num_procs();
       chunk = 1; }
   else {
       threads = strtol (argv[1],NULL,10);
       chunk = strtol (argv[2],NULL,10); }
   omp_set_num_threads(threads);
   printf ("Using %d threads, chunk size: %d\n", 
            threads, chunk);    
    struct timeval tv1, tv2;
    struct timezone tz;
    double elapsed; 
    omp_set_num_threads (omp_get_num_procs());
    for (i=0;i<N;i++) 
         for (j=0;j<N;j++) {
            A[i][j] = (double)rand()/RAND_MAX;
            B[i][j] = (double)rand()/RAND_MAX; }
    gettimeofday(&tv1, &tz);
        
    #pragma omp parallel private(i,j,k) shared(A,B,C) 
      #pragma omp master
        #pragma omp taskloop grainsize(chunk) 
        for (i=0;i<N;++i) {
             for (j=0;j<N;++j) {
                  for (k=0;k<N;++k) {
                       C[i][j]+=A[i][k]*B[k][j]; }}}
    gettimeofday(&tv2, &tz);
    elapsed = (double)(tv2.tv_sec-tv1.tv_sec)+
              (double)(tv2.tv_usec-tv1.tv_usec)*1.e-6;
    printf ("Elapsed time = %f seconds\n", elapsed); }


   
   
   
   
   
   
   
   
   
   
   
   
   
