#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

double func (double x) {
       return (3*pow(x,2)+1); }
       
double integrate (double a, double b, int N) {
   double x = a, localIntegral = 0.0;
   double base = (b-a) / N;	
   localIntegral = (func(a)+func(b))/2;
   localIntegral /= 2;
   #pragma omp parallel for private(x)
   for (int i=1;i<N;i++) {
   	x = a + i*base;
   	#pragma omp critical
   	localIntegral += func(x); }
   localIntegral = localIntegral * base;	
   return localIntegral;
}

void main (int argc, char ** argv) {

    double a,b, integral = 0.0;
    long int N, size;
    clock_t t1,t2;
    if (argc==1) size = 2;
    else size = strtol(argv[1],NULL,10);
    printf ("Number of threads is %ld\n", size);
    printf ("Give the value of a: "); scanf ("%lf", &a);
    printf ("Give the value of b: "); scanf ("%lf", &b);
    printf ("Give the value of N: "); scanf ("%ld", &N);
    t1 = clock();    
    integral = integrate (a,b,N);
    t2 = clock()-t1;  
    printf ("Integral: %.6f (N=%ld, T=%.6f secs)\n",
            integral, N, ((double)t2)/CLOCKS_PER_SEC); }
            
            
            
            
            
            
            
            
