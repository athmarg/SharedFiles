#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define THREADS 5
#define SAMPLES 1000

typedef struct dotProductStruct {
   double * aVector, * bVector;
   double product;
   int samples; } dotProductStruct;

dotProductStruct dStruct;
pthread_t threads [THREADS];
pthread_mutex_t mutexSum;

void * dotProduct (void * arg) {
   double sum=0.0, * xValues, * yValues;
   int start, end, length, counter;
   long offset = (long)arg;
   length = dStruct.samples;
   start = offset*length;
   end = start+length;
   xValues = dStruct.aVector;
   yValues = dStruct.bVector;
   for (counter=start;counter<end;counter++)
   sum += (xValues[counter]*yValues[counter]);
   pthread_mutex_lock (&mutexSum);
   dStruct.product += sum;
   pthread_mutex_unlock (&mutexSum);
   pthread_exit ((void *)0);
   return (0); }

int main(int argc, char * argv[]) {
   int counter, status;
   double * xVector, * yVector;
   pthread_attr_t attribute;
   xVector = (double *) malloc (SAMPLES*THREADS*sizeof(double));
   yVector = (double *) malloc (SAMPLES*THREADS*sizeof(double));
   for (counter=0;counter<SAMPLES*THREADS;counter++) {
   xVector[counter]=(double)rand()/RAND_MAX;
   yVector[counter]=(double)rand()/RAND_MAX; }
   dStruct.aVector = xVector;
   dStruct.bVector = yVector;
   dStruct.product = 0.0;
   dStruct.samples = SAMPLES;
   pthread_mutex_init (&mutexSum, NULL);
   pthread_attr_init (&attribute);
   pthread_attr_setdetachstate (&attribute, PTHREAD_CREATE_JOINABLE);
   for (counter=0;counter<THREADS;counter++)
        pthread_create (&threads[counter], &attribute, dotProduct, (void *)((long)counter));
   pthread_attr_destroy (&attribute);
   for (counter=0;counter<THREADS;counter++)
        pthread_join (threads[counter], (void **)&status);
   printf ("Vector product has a value of %.6f\n", dStruct.product);
   free (xVector); free (yVector);
   pthread_mutex_destroy (&mutexSum);
   pthread_exit (NULL);
   return (0); }
   
   
   
   
