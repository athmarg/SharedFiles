#include <stdio.h>
#include <omp.h>
#define N 15

int main (void) {
   int i, j=0;
   #pragma omp parallel for ordered \
           schedule (static,1) linear(j:3)
   for (i=0;i<N;i++) {
        printf ("Thread %02d ===> %02d %02d\n",
        omp_get_thread_num(), i,j); }
   return 0; }
   
   
   
   
