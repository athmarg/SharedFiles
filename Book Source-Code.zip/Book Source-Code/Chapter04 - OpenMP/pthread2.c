#include <pthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define THREADS 5

static void * threadFunc (void *arg) {
    char *s = (char *) arg;
    printf("%s", s);
    return (void *) strlen(s); }

int main(int argc, char *argv[]) {
   pthread_t threads [THREADS];
   void *res; int i, ret;
   for (i=0;i<THREADS;i++) {
   ret = pthread_create (&threads[i], NULL, threadFunc, "Hello world\n");
   if (!ret)
       printf ("Thread with TID %ld has been created succesfully\n", threads[i]); }
   printf ("Hello from the main thread !!\n");
   for (i=0;i<THREADS;i++) {
        ret = pthread_join (threads[i], &res);
        if (!ret)
            printf("Thread no %d returned %ld\n", i, (long) res); }
   exit(EXIT_SUCCESS); }


