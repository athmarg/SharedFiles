#include <omp.h>
#include <math.h>

#define N 10000

void initBuffers (double *x, double *y, int *index, int n) {
  int i;
  #pragma omp parallel for shared (x,y,index,n)
    for (i=0;i<n;i++) {
         #pragma omp atomic update
         x[index[i]] += (double)i;
         y[i] += (double)pow(i,2); }}

int main() {
  double x[N], y[N]; int index[N];
  int i;

  for (i=0;i<N;i++) { index[i]=i; y[i]=0.0; }
  for (i=0;i<1000; i++) x[i] = 0.0;
  initBuffers (x, y, index, N);
  return 0; }
  
  
  
  
  
  
